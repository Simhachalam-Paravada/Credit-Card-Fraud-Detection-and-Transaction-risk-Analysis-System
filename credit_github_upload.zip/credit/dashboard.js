document.addEventListener("DOMContentLoaded", () => {

    /* =========================================================
       API ENDPOINTS
       ========================================================= */

    const API_ANALYTICS = "/api/analytics";
    const API_HISTORY = "/api/history?limit=500";
    const API_HEALTH = "/api/health";
    const API_LOCATIONS = "/api/locations?limit=500";


    /* =========================================================
       GLOBAL STATE
       ========================================================= */

    let allTransactions = [];
    let allLocations = [];

    let charts = {};

    let riskMap = null;
    let mapMarkers = [];

    let refreshTimer = null;
    let resizeTimer = null;


    /* =========================================================
       DOM HELPER
       ========================================================= */

    const $ = (selector) => {
        return document.querySelector(selector);
    };


    /* =========================================================
       HTML ESCAPE
       ========================================================= */

    const escapeHTML = (value) => {

        return String(value ?? "")
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    };


    /* =========================================================
       NUMBER FORMAT
       ========================================================= */

    const formatNumber = (value, digits = 0) => {

        const number = Number(value || 0);

        return number.toLocaleString("en-IN", {
            minimumFractionDigits: digits,
            maximumFractionDigits: digits
        });
    };


    /* =========================================================
       TOAST
       ========================================================= */

    function showToast(message) {

        const toast = $("#toast");

        if (!toast) {
            return;
        }

        toast.textContent = message;

        toast.classList.add("show");

        clearTimeout(window.__toastTimer);

        window.__toastTimer = setTimeout(() => {

            toast.classList.remove("show");

        }, 2200);
    }


    /* =========================================================
       LEAFLET CSS FALLBACK
       ========================================================= */

    function ensureLeafletStyles() {

        const existing =
            document.querySelector(
                'link[href*="leaflet.css"]'
            );

        const fallback =
            document.querySelector(
                'link[data-leaflet-fallback="true"]'
            );


        /*
         * If dashboard.html doesn't contain Leaflet CSS,
         * add it dynamically.
         */

        if (!existing && !fallback) {

            const link =
                document.createElement("link");

            link.rel = "stylesheet";

            link.href =
                "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";

            link.setAttribute(
                "data-leaflet-fallback",
                "true"
            );

            document.head.appendChild(link);
        }


        /*
         * Backup stylesheet protects against
         * a broken integrity hash in HTML.
         */

        if (!fallback) {

            const backup =
                document.createElement("link");

            backup.rel = "stylesheet";

            backup.href =
                "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";

            backup.setAttribute(
                "data-leaflet-fallback",
                "true"
            );

            document.head.appendChild(backup);
        }
    }


    /* =========================================================
       PROFILE
       ========================================================= */

    function updateProfile() {

        const username =
            sessionStorage.getItem("username") ||
            localStorage.getItem("username");

        if (
            username &&
            $("#profileName")
        ) {

            $("#profileName").textContent =
                username;
        }
    }


    /* =========================================================
       SYSTEM STATUS
       ========================================================= */

    function setSystemStatus(online) {

        const status =
            $("#systemStatus");

        const dataChip =
            $("#dataChip");

        if (!status) {
            return;
        }

        status.textContent =
            online
                ? "System Online"
                : "System Offline";


        if (dataChip) {

            dataChip.textContent =
                online
                    ? "Live database data"
                    : "Backend unavailable";
        }
    }


    /* =========================================================
       KPI SUMMARY
       ========================================================= */

    function updateSummary(analytics) {

        if (!analytics) {
            return;
        }


        if ($("#totalTransactions")) {

            $("#totalTransactions").textContent =
                formatNumber(
                    analytics.total_predictions
                );
        }


        if ($("#fraudTransactions")) {

            $("#fraudTransactions").textContent =
                formatNumber(
                    analytics.fraud_predictions
                );
        }


        if ($("#fraudRate")) {

            $("#fraudRate").textContent =
                `${formatNumber(
                    analytics.fraud_rate,
                    2
                )}%`;
        }


        if ($("#averageRisk")) {

            $("#averageRisk").textContent =
                formatNumber(
                    analytics.average_risk_score,
                    2
                );
        }
    }


    /* =========================================================
       DATE FILTER
       ========================================================= */

    function applyDateFilter(
        transactions,
        days
    ) {

        if (days === "all") {

            return transactions;
        }


        const cutoff =
            new Date();

        cutoff.setHours(
            0,
            0,
            0,
            0
        );


        cutoff.setDate(
            cutoff.getDate() -
            Number(days)
        );


        return transactions.filter(
            (transaction) => {

                const dateValue =
                    transaction.transaction_date ||
                    transaction.created_at;


                if (!dateValue) {

                    return false;
                }


                const parsed =
                    new Date(dateValue);


                return (
                    !Number.isNaN(
                        parsed.getTime()
                    ) &&
                    parsed >= cutoff
                );
            }
        );
    }


    /* =========================================================
       BUILD DASHBOARD COUNTS
       ========================================================= */

    function buildCounts(transactions) {

        return transactions.reduce(
            (acc, transaction) => {

                /*
                 * Status counts
                 */

                if (
                    transaction.status ===
                    "FRAUD"
                ) {

                    acc.fraud += 1;

                } else if (

                    transaction.suspicious_flag ===
                    "SUSPICIOUS" ||

                    transaction.suspicious_flag ===
                    "REVIEW"

                ) {

                    acc.review += 1;

                } else {

                    acc.genuine += 1;
                }


                /*
                 * Risk counts
                 */

                if (
                    transaction.risk_level ===
                    "HIGH"
                ) {

                    acc.high += 1;

                } else if (
                    transaction.risk_level ===
                    "MEDIUM"
                ) {

                    acc.medium += 1;

                } else {

                    acc.low += 1;
                }


                return acc;

            },
            {
                genuine: 0,
                fraud: 0,
                review: 0,
                low: 0,
                medium: 0,
                high: 0
            }
        );
    }


    /* =========================================================
       DONUT LEGEND
       ========================================================= */

    function renderLegend(counts) {

        const genuine =
            counts.genuine;

        const fraud =
            counts.fraud;

        const review =
            counts.review;


        /*
         * Include all three categories
         * in total.
         */

        const total =
            genuine +
            fraud +
            review;


        const safeTotal =
            total || 1;


        const items = [

            {
                name: "Genuine",
                value: genuine,
                dot: "#18a67c"
            },

            {
                name: "Fraud",
                value: fraud,
                dot: "#e94f64"
            },

            {
                name: "Review",
                value: review,
                dot: "#ed9b32"
            }

        ];


        const legend =
            $("#statusLegend");


        if (!legend) {

            return;
        }


        legend.innerHTML =
            items.map(
                (item) => `

                    <div class="legend-item">

                        <span
                            class="legend-dot"
                            style="background:${item.dot}">
                        </span>


                        <div>

                            <small>
                                ${escapeHTML(
                                    item.name
                                )}
                            </small>

                            <br>

                            <strong>
                                ${formatNumber(
                                    item.value
                                )}
                            </strong>

                        </div>


                        <small>
                            ${formatNumber(
                                (
                                    item.value /
                                    safeTotal
                                ) * 100,
                                1
                            )}%
                        </small>

                    </div>

                `
            ).join("");


        const statusTotal =
            $("#statusTotalLabel");


        if (statusTotal) {

            statusTotal.textContent =
                `${formatNumber(
                    total
                )} analyzed`;
        }
    }


    /* =========================================================
       FRAUD VS GENUINE DONUT CHART
       ========================================================= */

    function renderStatusChart(
        counts
    ) {

        const canvas =
            $("#statusChart");


        if (
            !canvas ||
            typeof Chart === "undefined"
        ) {

            return;
        }


        /*
         * Destroy previous chart.
         */

        if (charts.status) {

            charts.status.destroy();
        }


        charts.status =
            new Chart(
                canvas,
                {

                    type: "doughnut",


                    data: {

                        labels: [
                            "Genuine",
                            "Fraud",
                            "Review"
                        ],


                        datasets: [

                            {

                                data: [

                                    counts.genuine,
                                    counts.fraud,
                                    counts.review

                                ],


                                backgroundColor: [

                                    "#16a77e",
                                    "#e94f64",
                                    "#eda039"

                                ],


                                borderWidth: 0,


                                hoverOffset: 6

                            }

                        ]

                    },


                    options: {

                        responsive: true,

                        maintainAspectRatio: false,

                        cutout: "72%",


                        animation: {

                            duration: 500

                        },


                        plugins: {

                            legend: {

                                display: false

                            },


                            tooltip: {

                                callbacks: {

                                    label:
                                        (context) =>
                                            `${context.label}: ${formatNumber(
                                                context.raw
                                            )}`

                                }

                            }

                        }

                    }

                }
            );


        renderLegend(
            counts
        );
    }


    /* =========================================================
       RISK DISTRIBUTION BAR CHART
       ========================================================= */

    function renderRiskChart(
        counts
    ) {

        const canvas =
            $("#riskChart");


        if (
            !canvas ||
            typeof Chart === "undefined"
        ) {

            return;
        }


        if (charts.risk) {

            charts.risk.destroy();
        }


        charts.risk =
            new Chart(
                canvas,
                {

                    type: "bar",


                    data: {

                        labels: [
                            "LOW",
                            "MEDIUM",
                            "HIGH"
                        ],


                        datasets: [

                            {

                                data: [

                                    counts.low,
                                    counts.medium,
                                    counts.high

                                ],


                                backgroundColor: [

                                    "#18a67c",
                                    "#eda039",
                                    "#e94f64"

                                ],


                                borderRadius: 8,


                                maxBarThickness: 34

                            }

                        ]

                    },


                    options: {

                        responsive: true,

                        maintainAspectRatio: false,


                        animation: {

                            duration: 500

                        },


                        plugins: {

                            legend: {

                                display: false

                            }

                        },


                        scales: {

                            x: {

                                grid: {

                                    display: false

                                },

                                ticks: {

                                    color:
                                        "#78869b",

                                    font: {

                                        size: 9,

                                        weight: "700"

                                    }

                                }

                            },


                            y: {

                                beginAtZero: true,

                                grid: {

                                    color:
                                        "#edf1f5"

                                },

                                ticks: {

                                    color:
                                        "#8a96a8",

                                    precision: 0,

                                    font: {

                                        size: 9

                                    }

                                },

                                border: {

                                    display: false

                                }

                            }

                        }

                    }

                }
            );
    }


    /* =========================================================
       TRANSACTION ACTIVITY BY HOUR
       ========================================================= */

    function renderHourlyChart(
        transactions
    ) {

        const counts =
            new Array(24).fill(0);


        transactions.forEach(
            (transaction) => {

                if (
                    !transaction.transaction_time
                ) {

                    return;
                }


                const hour =
                    Number(
                        String(
                            transaction.transaction_time
                        ).split(":")[0]
                    );


                if (
                    Number.isInteger(hour) &&
                    hour >= 0 &&
                    hour <= 23
                ) {

                    counts[hour] += 1;
                }
            }
        );


        const canvas =
            $("#hourChart");


        if (
            !canvas ||
            typeof Chart === "undefined"
        ) {

            return;
        }


        if (charts.hour) {

            charts.hour.destroy();
        }


        charts.hour =
            new Chart(
                canvas,
                {

                    type: "line",


                    data: {

                        labels:
                            counts.map(
                                (_, index) =>
                                    `${String(
                                        index
                                    ).padStart(
                                        2,
                                        "0"
                                    )}:00`
                            ),


                        datasets: [

                            {

                                label:
                                    "Transactions",


                                data:
                                    counts,


                                borderColor:
                                    "#2563eb",


                                backgroundColor:
                                    "rgba(37,99,235,.08)",


                                fill: true,


                                tension: .35,


                                pointRadius: 2,


                                pointHoverRadius: 4,


                                borderWidth: 2

                            }

                        ]

                    },


                    options: {

                        responsive: true,

                        maintainAspectRatio: false,


                        animation: {

                            duration: 500

                        },


                        plugins: {

                            legend: {

                                display: false

                            }

                        },


                        scales: {

                            x: {

                                grid: {

                                    display: false

                                },

                                ticks: {

                                    maxTicksLimit: 8,

                                    color:
                                        "#8794a7",

                                    font: {

                                        size: 8

                                    }

                                }

                            },


                            y: {

                                beginAtZero: true,

                                grid: {

                                    color:
                                        "#edf1f5"

                                },

                                ticks: {

                                    color:
                                        "#8b97a9",

                                    precision: 0,

                                    font: {

                                        size: 8

                                    }

                                },

                                border: {

                                    display: false

                                }

                            }

                        }

                    }

                }
            );
    }


    /* =========================================================
       RISK SIGNALS
       ========================================================= */

    function renderSignals(
        transactions
    ) {

        if (!transactions.length) {

            if (
                $("#highestRiskText")
            ) {

                $("#highestRiskText")
                    .textContent =
                    "No data available";
            }


            if (
                $("#topMerchantText")
            ) {

                $("#topMerchantText")
                    .textContent =
                    "No data available";
            }


            if (
                $("#latestFraudText")
            ) {

                $("#latestFraudText")
                    .textContent =
                    "No fraud detected yet";
            }


            return;
        }


        /*
         * Highest risk transaction
         */

        const sortedRisk =
            [...transactions].sort(
                (a, b) =>
                    Number(
                        b.risk_score || 0
                    ) -
                    Number(
                        a.risk_score || 0
                    )
            );


        const highest =
            sortedRisk[0];


        /*
         * Latest fraud
         */

        const frauds =
            transactions.filter(
                (transaction) =>
                    transaction.status ===
                    "FRAUD"
            );


        const latestFraud =
            [...frauds].sort(
                (a, b) =>
                    Number(
                        b.id || 0
                    ) -
                    Number(
                        a.id || 0
                    )
            )[0];


        /*
         * Most analyzed merchant
         */

        const merchantCounts = {};


        transactions.forEach(
            (transaction) => {

                const merchant =
                    transaction.merchant ||
                    "Unknown";


                merchantCounts[
                    merchant
                ] =
                    (
                        merchantCounts[
                            merchant
                        ] || 0
                    ) + 1;
            }
        );


        const topMerchant =
            Object.entries(
                merchantCounts
            ).sort(
                (a, b) =>
                    b[1] -
                    a[1]
            )[0];


        /*
         * Highest risk display
         */

        if (
            $("#highestRiskText")
        ) {

            $("#highestRiskText")
                .textContent =
                highest

                    ? `TXN-${highest.id} • ${formatNumber(
                        highest.risk_score,
                        2
                    )}% risk`

                    : "No data available";
        }


        /*
         * Merchant display
         */

        if (
            $("#topMerchantText")
        ) {

            $("#topMerchantText")
                .textContent =
                topMerchant

                    ? `${topMerchant[0]} • ${formatNumber(
                        topMerchant[1]
                    )} transactions`

                    : "No data available";
        }


        /*
         * Latest fraud display
         */

        if (
            $("#latestFraudText")
        ) {

            $("#latestFraudText")
                .textContent =
                latestFraud

                    ? `TXN-${latestFraud.id} • ${
                        latestFraud.merchant ||
                        "Unknown merchant"
                    }`

                    : "No fraud detected yet";
        }
    }


    /* =========================================================
       MAP RISK COLOR
       ========================================================= */

    function riskColor(level) {

        if (
            String(level).toUpperCase() ===
            "HIGH"
        ) {

            return "#e84e63";
        }


        if (
            String(level).toUpperCase() ===
            "MEDIUM"
        ) {

            return "#eea13d";
        }


        return "#15a77a";
    }


    /* =========================================================
       INITIALIZE LEAFLET MAP
       ========================================================= */

    function initRiskMap() {

        const mapElement =
            document.getElementById(
                "fraudRiskMap"
            );


        if (!mapElement) {

            return;
        }


        ensureLeafletStyles();


        /*
         * Leaflet JS must exist.
         */

        if (
            typeof L === "undefined"
        ) {

            console.error(
                "Leaflet JS is not loaded."
            );

            return;
        }


        /*
         * Don't initialize twice.
         */

        if (riskMap) {

            return;
        }


        /*
         * Create India-centered map.
         */

        riskMap =
            L.map(
                mapElement,
                {

                    zoomControl: true,

                    scrollWheelZoom: true,

                    doubleClickZoom: true,

                    dragging: true,

                    boxZoom: true,

                    keyboard: true

                }
            )
            .setView(
                [
                    20.5937,
                    78.9629
                ],
                5
            );


        /*
         * OpenStreetMap tiles
         */

        L.tileLayer(
            "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            {

                maxZoom: 19,

                attribution:
                    '&copy; OpenStreetMap contributors',

                tileSize: 256,

                updateWhenZooming: false,

                keepBuffer: 2

            }
        )
        .addTo(
            riskMap
        );


        /*
         * Scale control
         */

        L.control
            .scale(
                {
                    imperial: false
                }
            )
            .addTo(
                riskMap
            );


        /*
         * Force map redraw
         */

        setTimeout(
            () => {

                if (riskMap) {

                    riskMap.invalidateSize(
                        true
                    );
                }

            },
            300
        );


        /*
         * Resize redraw
         */

        window.addEventListener(
            "resize",
            () => {

                clearTimeout(
                    resizeTimer
                );


                resizeTimer =
                    setTimeout(
                        () => {

                            if (riskMap) {

                                riskMap.invalidateSize(
                                    true
                                );
                            }

                        },
                        200
                    );
            }
        );
    }


    /* =========================================================
       MAP POPUP
       ========================================================= */

    function mapPopup(
        transaction
    ) {

        const risk =
            transaction.risk_level ||
            "LOW";


        const riskClass =
            String(risk).toUpperCase() ===
            "HIGH"

                ? "high"

                : String(risk).toUpperCase() ===
                  "MEDIUM"

                    ? "medium"

                    : "low";


        return `

            <div class="map-popup">

                <h4>
                    TXN-${escapeHTML(
                        transaction.id
                    )}
                </h4>


                <p>
                    <strong>Location:</strong>
                    ${escapeHTML(
                        transaction.location ||
                        "—"
                    )}
                </p>


                <p>
                    <strong>Merchant:</strong>
                    ${escapeHTML(
                        transaction.merchant ||
                        "—"
                    )}
                </p>


                <p>
                    <strong>Amount:</strong>
                    ₹${formatNumber(
                        transaction.amount,
                        2
                    )}
                </p>


                <p>
                    <strong>Risk Score:</strong>
                    ${formatNumber(
                        transaction.risk_score,
                        2
                    )}%
                </p>


                <p>
                    <strong>Status:</strong>
                    ${escapeHTML(
                        transaction.status ||
                        "—"
                    )}
                </p>


                <span
                    class="popup-risk ${riskClass}"
                >
                    ${escapeHTML(
                        String(risk).toUpperCase()
                    )}
                    RISK
                </span>

            </div>

        `;
    }


    /* =========================================================
       RENDER MAP
       ========================================================= */

    function renderRiskMap(
        locationData
    ) {

        initRiskMap();


        const mapElement =
            document.getElementById(
                "fraudRiskMap"
            );


        if (
            !riskMap ||
            !mapElement
        ) {

            return;
        }


        /*
         * Remove existing markers.
         */

        mapMarkers.forEach(
            (marker) => {

                riskMap.removeLayer(
                    marker
                );
            }
        );


        mapMarkers = [];


        /*
         * Normalize location response.
         */

        let points = [];


        if (
            Array.isArray(
                locationData
            )
        ) {

            points =
                locationData;

        } else if (
            locationData &&
            Array.isArray(
                locationData.data
            )
        ) {

            points =
                locationData.data;

        } else if (
            locationData &&
            locationData.data &&
            Array.isArray(
                locationData.data.data
            )
        ) {

            points =
                locationData.data.data;
        }


        /*
         * Keep valid coordinates only.
         */

        const validPoints =
            points.filter(
                (item) => {

                    const latitude =
                        Number(
                            item.latitude
                        );

                    const longitude =
                        Number(
                            item.longitude
                        );


                    return (

                        Number.isFinite(
                            latitude
                        ) &&

                        Number.isFinite(
                            longitude
                        ) &&

                        latitude >= -90 &&

                        latitude <= 90 &&

                        longitude >= -180 &&

                        longitude <= 180

                    );
                }
            );


        /*
         * Draw map markers.
         */

        validPoints.forEach(
            (transaction) => {

                const color =
                    riskColor(
                        transaction.risk_level
                    );


                const highRisk =
                    String(
                        transaction.risk_level ||
                        ""
                    ).toUpperCase() ===
                    "HIGH";


                const marker =
                    L.circleMarker(
                        [

                            Number(
                                transaction.latitude
                            ),

                            Number(
                                transaction.longitude
                            )

                        ],
                        {

                            radius:
                                highRisk
                                    ? 9
                                    : 7,

                            color:
                                color,

                            fillColor:
                                color,

                            fillOpacity:
                                highRisk
                                    ? 0.85
                                    : 0.72,

                            weight: 2

                        }
                    )
                    .addTo(
                        riskMap
                    );


                /*
                 * Popup
                 */

                marker.bindPopup(
                    mapPopup(
                        transaction
                    )
                );


                /*
                 * Tooltip
                 */

                marker.bindTooltip(

                    `TXN-${transaction.id} • ${
                        transaction.location ||
                        "Location"
                    }`,

                    {

                        direction: "top",

                        opacity: 0.92

                    }
                );


                mapMarkers.push(
                    marker
                );
            }
        );


        /*
         * Fit map to transaction points.
         */

        const bounds =
            validPoints.map(
                (item) => [

                    Number(
                        item.latitude
                    ),

                    Number(
                        item.longitude
                    )

                ]
            );


        if (
            bounds.length > 1
        ) {

            riskMap.fitBounds(
                bounds,
                {

                    padding: [
                        40,
                        40
                    ],

                    maxZoom: 11

                }
            );

        } else if (
            bounds.length === 1
        ) {

            riskMap.setView(
                bounds[0],
                10
            );

        } else {

            /*
             * Default India view
             */

            riskMap.setView(
                [
                    20.5937,
                    78.9629
                ],
                5
            );
        }


        /* =====================================================
           MAP SUMMARY
           ===================================================== */

        const total =
            validPoints.length;


        const high =
            validPoints.filter(
                (item) =>
                    String(
                        item.risk_level ||
                        ""
                    ).toUpperCase() ===
                    "HIGH"
            ).length;


        const fraud =
            validPoints.filter(
                (item) =>
                    String(
                        item.status ||
                        ""
                    ).toUpperCase() ===
                    "FRAUD"
            ).length;


        const uniqueLocations =
            new Set(
                validPoints.map(
                    (item) =>
                        String(
                            item.location ||
                            `${item.latitude},${item.longitude}`
                        )
                        .trim()
                        .toLowerCase()
                )
            );


        const locationCount =
            uniqueLocations.size;


        if (
            $("#mapTransactionCount")
        ) {

            $("#mapTransactionCount")
                .textContent =
                `${formatNumber(
                    locationCount
                )} locations`;
        }


        if (
            $("#mapTotal")
        ) {

            $("#mapTotal")
                .textContent =
                formatNumber(
                    total
                );
        }


        if (
            $("#mapHighRisk")
        ) {

            $("#mapHighRisk")
                .textContent =
                formatNumber(
                    high
                );
        }


        if (
            $("#mapFraud")
        ) {

            $("#mapFraud")
                .textContent =
                formatNumber(
                    fraud
                );
        }


        /*
         * Final redraw
         */

        setTimeout(
            () => {

                if (riskMap) {

                    riskMap.invalidateSize(
                        true
                    );
                }

            },
            250
        );
    }


    /* =========================================================
       LOAD DASHBOARD DATA
       ========================================================= */

    async function refreshDashboard() {

        const refreshIcon =
            $("#refreshBtn i");


        if (refreshIcon) {

            refreshIcon.classList.add(
                "fa-spin"
            );
        }


        try {

            /*
             * Parallel API calls.
             */

            const [

                analyticsResponse,

                historyResponse,

                healthResponse,

                locationsResponse

            ] = await Promise.all([

                fetch(
                    API_ANALYTICS,
                    {
                        cache:
                            "no-store"
                    }
                ),

                fetch(
                    API_HISTORY,
                    {
                        cache:
                            "no-store"
                    }
                ),

                fetch(
                    API_HEALTH,
                    {
                        cache:
                            "no-store"
                    }
                ),

                fetch(
                    API_LOCATIONS,
                    {
                        cache:
                            "no-store"
                    }
                )
                .catch(
                    () => null
                )

            ]);


            /*
             * Required APIs.
             */

            if (
                !analyticsResponse.ok ||
                !historyResponse.ok
            ) {

                throw new Error(
                    "Unable to load dashboard data."
                );
            }


            /*
             * Parse responses.
             */

            const analytics =
                await analyticsResponse.json();


            const history =
                await historyResponse.json();


            const health =
                healthResponse &&
                healthResponse.ok

                    ? await healthResponse.json()

                    : null;


            const locations =
                locationsResponse &&
                locationsResponse.ok

                    ? await locationsResponse.json()

                    : null;


            /* =================================================
               HISTORY DATA
               ================================================= */

            if (
                Array.isArray(
                    history
                )
            ) {

                allTransactions =
                    history;

            } else if (
                history &&
                Array.isArray(
                    history.data
                )
            ) {

                allTransactions =
                    history.data;

            } else if (
                history &&
                history.data &&
                Array.isArray(
                    history.data.data
                )
            ) {

                allTransactions =
                    history.data.data;

            } else {

                allTransactions =
                    [];
            }


            /* =================================================
               LOCATION DATA
               ================================================= */

            if (
                Array.isArray(
                    locations
                )
            ) {

                allLocations =
                    locations;

            } else if (
                locations &&
                Array.isArray(
                    locations.data
                )
            ) {

                allLocations =
                    locations.data;

            } else if (
                locations &&
                locations.data &&
                Array.isArray(
                    locations.data.data
                )
            ) {

                allLocations =
                    locations.data.data;

            } else {

                allLocations =
                    [];
            }


            /*
             * Debug information.
             */

            console.log(
                "Dashboard analytics response:",
                analytics
            );


            console.log(
                "Dashboard history response:",
                history
            );


            console.log(
                "Loaded transactions:",
                allTransactions.length
            );


            console.log(
                "Dashboard locations response:",
                locations
            );


            console.log(
                "Loaded locations:",
                allLocations.length
            );


            /* =================================================
               UPDATE UI
               ================================================= */

            setSystemStatus(
                health
                    ? Boolean(
                        health.success
                    )
                    : true
            );


            updateSummary(
                analytics
            );


            renderDashboard();


            /*
             * Updated time
             */

            if (
                $("#lastUpdated")
            ) {

                $("#lastUpdated")
                    .textContent =
                    `Last updated ${
                        new Date()
                            .toLocaleTimeString(
                                "en-IN",
                                {

                                    hour:
                                        "2-digit",

                                    minute:
                                        "2-digit"

                                }
                            )
                    }`;
            }


        } catch (error) {

            console.error(
                "Dashboard refresh error:",
                error
            );


            setSystemStatus(
                false
            );


            showToast(
                "Could not load live dashboard data."
            );


            /*
             * Keep dashboard charts stable
             * even if one request fails.
             */

        } finally {

            if (refreshIcon) {

                setTimeout(
                    () => {

                        refreshIcon.classList.remove(
                            "fa-spin"
                        );

                    },
                    450
                );
            }
        }
    }


    /* =========================================================
       RENDER DASHBOARD
       ========================================================= */

    function renderDashboard() {

        const selectedDays =
            $("#dateFilter")?.value ||
            "all";


        const filtered =
            applyDateFilter(
                allTransactions,
                selectedDays
            );


        const counts =
            buildCounts(
                filtered
            );


        /*
         * Render charts
         */

        renderStatusChart(
            counts
        );


        renderRiskChart(
            counts
        );


        renderHourlyChart(
            filtered
        );


        /*
         * Render signals
         */

        renderSignals(
            filtered
        );


        /*
         * Map filtering
         *
         * Keep only location records that
         * belong to the filtered transactions.
         */

        const filteredIds =
            new Set(
                filtered.map(
                    (item) =>
                        Number(
                            item.id
                        )
                )
            );


        const filteredLocations =
            allLocations.filter(
                (item) =>
                    filteredIds.has(
                        Number(
                            item.id
                        )
                )
            );


        /*
         * If the locations endpoint does not
         * include matching IDs, use all locations
         * instead of showing a blank map.
         */

        if (
            filteredLocations.length
        ) {

            renderRiskMap(
                filteredLocations
            );

        } else if (
            allLocations.length
        ) {

            renderRiskMap(
                allLocations
            );

        } else {

            renderRiskMap(
                []
            );
        }
    }


    /* =========================================================
       KPI INTERACTIONS
       ========================================================= */

    function bindKPIInteractions() {

        document
            .querySelectorAll(
                ".summary-card"
            )
            .forEach(
                (card) => {

                    card.addEventListener(
                        "click",
                        () => {

                            const action =
                                card.dataset.action ||
                                "";


                            /*
                             * Fraud KPI
                             */

                            if (
                                action ===
                                "fraud"
                            ) {

                                $("#riskMapSection")
                                    ?.scrollIntoView(
                                        {

                                            behavior:
                                                "smooth",

                                            block:
                                                "start"

                                        }
                                    );


                                showToast(
                                    "Fraud monitoring view opened."
                                );


                                return;
                            }


                            /*
                             * Fraud Rate KPI
                             */

                            if (
                                action ===
                                "rate"
                            ) {

                                $("#statusChart")
                                    ?.closest(".panel")
                                    ?.scrollIntoView(
                                        {

                                            behavior:
                                                "smooth",

                                            block:
                                                "start"

                                        }
                                    );


                                return;
                            }


                            /*
                             * Average Risk KPI
                             */

                            if (
                                action ===
                                "risk"
                            ) {

                                $("#riskChart")
                                    ?.closest(".panel")
                                    ?.scrollIntoView(
                                        {

                                            behavior:
                                                "smooth",

                                            block:
                                                "start"

                                        }
                                    );


                                return;
                            }


                            /*
                             * Total Transactions KPI
                             */

                            $("#riskMapSection")
                                ?.scrollIntoView(
                                    {

                                        behavior:
                                            "smooth",

                                        block:
                                            "start"

                                    }
                                );
                        }
                    );
                }
            );
    }


    /* =========================================================
       FILTER INTERACTIONS
       ========================================================= */

    function bindFilterInteractions() {

        /*
         * Date filter
         */

        $("#dateFilter")
            ?.addEventListener(
                "change",
                () => {

                    renderDashboard();
                }
            );


        /*
         * Clear filters
         */

        $("#clearFiltersBtn")
            ?.addEventListener(
                "click",
                () => {

                    if (
                        $("#dateFilter")
                    ) {

                        $("#dateFilter")
                            .value =
                            "all";
                    }


                    renderDashboard();


                    showToast(
                        "Filters cleared."
                    );
                }
            );
    }


    /* =========================================================
       MAP BUTTON
       ========================================================= */

    function bindMapInteractions() {

        $("#fitMapBtn")
            ?.addEventListener(
                "click",
                () => {

                    if (
                        !riskMap
                    ) {

                        showToast(
                            "Map is not available."
                        );

                        return;
                    }


                    if (
                        mapMarkers.length
                    ) {

                        const group =
                            L.featureGroup(
                                mapMarkers
                            );


                        const bounds =
                            group.getBounds();


                        if (
                            bounds.isValid()
                        ) {

                            riskMap.fitBounds(
                                bounds,
                                {

                                    padding: [
                                        40,
                                        40
                                    ],

                                    maxZoom: 11

                                }
                            );

                        }

                    } else {

                        riskMap.setView(
                            [
                                20.5937,
                                78.9629
                            ],
                            5
                        );


                        showToast(
                            "No mapped transactions available."
                        );
                    }
                }
            );
    }


    /* =========================================================
       REFRESH BUTTON
       ========================================================= */

    function bindRefreshInteractions() {

        $("#refreshBtn")
            ?.addEventListener(
                "click",
                async () => {

                    await refreshDashboard();

                    showToast(
                        "Dashboard refreshed."
                    );
                }
            );


        $("#footerRefresh")
            ?.addEventListener(
                "click",
                async () => {

                    await refreshDashboard();

                    showToast(
                        "Dashboard refreshed."
                    );
                }
            );
    }


    /* =========================================================
       AUTO REFRESH
       ========================================================= */

    function startAutoRefresh() {

        clearInterval(
            refreshTimer
        );


        refreshTimer =
            setInterval(
                () => {

                    refreshDashboard();

                },
                60000
            );
    }


    /* =========================================================
       OPTIONAL PANEL HIGHLIGHT
       ========================================================= */

    function addPanelHighlight() {

        document
            .querySelectorAll(
                ".summary-card"
            )
            .forEach(
                (card) => {

                    card.addEventListener(
                        "mouseenter",
                        () => {

                            card.classList.add(
                                "kpi-hover"
                            );
                        }
                    );


                    card.addEventListener(
                        "mouseleave",
                        () => {

                            card.classList.remove(
                                "kpi-hover"
                            );
                        }
                    );
                }
            );
    }


    /* =========================================================
       INITIALIZE EVERYTHING
       ========================================================= */

    function initializeDashboard() {

        /*
         * Leaflet
         */

        ensureLeafletStyles();

        initRiskMap();


        /*
         * Profile
         */

        updateProfile();


        /*
         * Buttons
         */

        bindRefreshInteractions();

        bindFilterInteractions();

        bindMapInteractions();

        bindKPIInteractions();


        /*
         * Small visual interaction
         */

        addPanelHighlight();


        /*
         * First data load
         */

        refreshDashboard();


        /*
         * Automatic refresh every 60 seconds
         */

        startAutoRefresh();
    }


    /* =========================================================
       START
       ========================================================= */

    initializeDashboard();

});