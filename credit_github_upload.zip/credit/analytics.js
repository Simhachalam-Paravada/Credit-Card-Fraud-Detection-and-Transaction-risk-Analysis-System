document.addEventListener("DOMContentLoaded", function () {

    let transactions = [];

    // =========================================================
    // LOAD REAL DATA FROM BACKEND
    // =========================================================

    async function loadAnalytics() {

        try {

            const response = await fetch(
                "/api/history?limit=500"
            );

            const result = await response.json();


            if (!response.ok || !result.success) {

                throw new Error(
                    result.error ||
                    "Unable to load analytics data."
                );

            }


            transactions = result.data || [];


            // Update every section of the existing UI

            updateRiskCards(transactions);

            updateMerchantTable(transactions);

            updateLocationTable(transactions);

            updatePeakFraudHours(transactions);

            updateSpendingPattern(transactions);

            updateRecentFraudTrends(transactions);

            updateFilterOptions(transactions);

            updateAnalyticsHeader(transactions);


            console.log(
                "Live Analytics:",
                transactions
            );


        } catch (error) {

            console.error(
                "Analytics Error:",
                error
            );

        }

    }


    // =========================================================
    // RISK CARDS
    // =========================================================

    function updateRiskCards(data) {

        let low = 0;

        let medium = 0;

        let high = 0;


        data.forEach(transaction => {

            const risk =
                String(
                    transaction.risk_level || "LOW"
                ).toUpperCase();


            if (risk === "HIGH") {

                high++;

            }

            else if (risk === "MEDIUM") {

                medium++;

            }

            else {

                low++;

            }

        });


        const lowElement =
            document.querySelector(
                ".low-risk h2"
            );


        const mediumElement =
            document.querySelector(
                ".medium-risk h2"
            );


        const highElement =
            document.querySelector(
                ".high-risk h2"
            );


        if (lowElement) {

            lowElement.textContent =
                formatNumber(low);

        }


        if (mediumElement) {

            mediumElement.textContent =
                formatNumber(medium);

        }


        if (highElement) {

            highElement.textContent =
                formatNumber(high);

        }


        // IMPORTANT:
        // Existing "98.4%" model accuracy
        // is NOT replaced with fake live data.
        //
        // Actual model metrics belong to
        // the ML evaluation results, not
        // transaction-history analytics.

    }


    // =========================================================
    // MERCHANT TABLE
    // =========================================================

    function updateMerchantTable(data) {

        const analysisBoxes =
            document.querySelectorAll(
                ".analysis-box"
            );


        if (analysisBoxes.length === 0) {

            return;

        }


        // First analysis box = merchant analysis

        const merchantBox =
            analysisBoxes[0];


        const tbody =
            merchantBox.querySelector(
                "tbody"
            );


        if (!tbody) {

            return;

        }


        const merchantStats = {};


        data.forEach(transaction => {

            if (
                transaction.status !== "FRAUD"
            ) {

                return;

            }


            const merchant =
                transaction.merchant ||
                "Unknown";


            if (
                !merchantStats[merchant]
            ) {

                merchantStats[merchant] = {

                    fraudCases: 0,

                    totalRisk: 0

                };

            }


            merchantStats[merchant]
                .fraudCases++;


            merchantStats[merchant]
                .totalRisk += Number(
                    transaction.risk_score || 0
                );

        });


        const sorted =
            Object.entries(
                merchantStats
            )
            .sort(
                (a, b) =>
                    b[1].fraudCases -
                    a[1].fraudCases
            )
            .slice(0, 5);


        tbody.innerHTML = "";


        if (sorted.length === 0) {

            tbody.innerHTML = `

                <tr>
                    <td colspan="3">
                        No fraud transactions yet.
                    </td>
                </tr>

            `;

            return;

        }


        sorted.forEach(
            ([merchant, stats]) => {

                const averageRisk =
                    stats.totalRisk /
                    stats.fraudCases;


                let riskLabel = "Low";


                if (averageRisk >= 70) {

                    riskLabel = "High";

                }

                else if (
                    averageRisk >= 40
                ) {

                    riskLabel = "Medium";

                }


                const row =
                    document.createElement(
                        "tr"
                    );


                row.innerHTML = `

                    <td>
                        ${merchant}
                    </td>

                    <td>
                        ${stats.fraudCases}
                    </td>

                    <td>
                        ${riskLabel}
                    </td>

                `;


                tbody.appendChild(row);

            }
        );

    }


    // =========================================================
    // LOCATION TABLE
    // =========================================================

    function updateLocationTable(data) {

        const analysisBoxes =
            document.querySelectorAll(
                ".analysis-box"
            );


        if (analysisBoxes.length < 3) {

            return;

        }


        // Third analysis box = locations

        const locationBox =
            analysisBoxes[2];


        const tbody =
            locationBox.querySelector(
                "tbody"
            );


        if (!tbody) {

            return;

        }


        const locationStats = {};


        data.forEach(transaction => {

            if (
                transaction.status !== "FRAUD"
            ) {

                return;

            }


            const location =
                transaction.location ||
                "Unknown";


            if (
                !locationStats[location]
            ) {

                locationStats[location] = {

                    count: 0,

                    totalRisk: 0

                };

            }


            locationStats[location].count++;


            locationStats[location]
                .totalRisk += Number(
                    transaction.risk_score || 0
                );

        });


        const sorted =
            Object.entries(
                locationStats
            )
            .sort(
                (a, b) =>
                    b[1].count -
                    a[1].count
            )
            .slice(0, 5);


        tbody.innerHTML = "";


        if (sorted.length === 0) {

            tbody.innerHTML = `

                <tr>
                    <td colspan="3">
                        No fraud transactions yet.
                    </td>
                </tr>

            `;

            return;

        }


        sorted.forEach(
            ([location, stats]) => {

                const averageRisk =
                    stats.totalRisk /
                    stats.count;


                let riskLabel = "Low";


                if (averageRisk >= 70) {

                    riskLabel = "High";

                }

                else if (
                    averageRisk >= 40
                ) {

                    riskLabel = "Medium";

                }


                const row =
                    document.createElement(
                        "tr"
                    );


                row.innerHTML = `

                    <td>
                        ${location}
                    </td>

                    <td>
                        ${stats.count}
                    </td>

                    <td>
                        ${riskLabel}
                    </td>

                `;


                tbody.appendChild(row);

            }
        );

    }


    // =========================================================
    // PEAK FRAUD HOURS
    // =========================================================

    function updatePeakFraudHours(data) {

        const fraudHours = {};


        data.forEach(transaction => {

            if (
                transaction.status !== "FRAUD"
            ) {

                return;

            }


            const time =
                transaction.transaction_time;


            if (!time) {

                return;

            }


            const hour = parseInt(
                String(time).split(":")[0],
                10
            );


            if (isNaN(hour)) {

                return;

            }


            fraudHours[hour] =
                (fraudHours[hour] || 0) + 1;

        });


        const sortedHours =
            Object.entries(
                fraudHours
            )
            .sort(
                (a, b) =>
                    b[1] - a[1]
            )
            .slice(0, 3);


        const analysisBoxes =
            document.querySelectorAll(
                ".analysis-box"
            );


        if (analysisBoxes.length < 2) {

            return;

        }


        const peakBox =
            analysisBoxes[1];


        const timeCards =
            peakBox.querySelectorAll(
                ".time-card"
            );


        if (sortedHours.length === 0) {

            return;

        }


        sortedHours.forEach(
            ([hour, count], index) => {

                if (!timeCards[index]) {

                    return;

                }


                const startHour =
                    Number(hour);


                const endHour =
                    (startHour + 3) % 24;


                const formattedStart =
                    formatHour(
                        startHour
                    );


                const formattedEnd =
                    formatHour(
                        endHour
                    );


                const heading =
                    timeCards[index]
                        .querySelector("h3");


                const paragraph =
                    timeCards[index]
                        .querySelector("p");


                if (heading) {

                    heading.textContent =
                        `${formattedStart} - ${formattedEnd}`;

                }


                if (paragraph) {

                    paragraph.textContent =
                        `${count} fraud transaction(s)`;

                }

            }
        );

    }


    // =========================================================
    // CUSTOMER SPENDING PATTERN
    // =========================================================

    function updateSpendingPattern(data) {

        const analysisBoxes =
            document.querySelectorAll(
                ".analysis-box"
            );


        if (analysisBoxes.length < 4) {

            return;

        }


        // Fourth analysis box = spending pattern

        const spendingBox =
            analysisBoxes[3];


        const timeCards =
            spendingBox.querySelectorAll(
                ".time-card"
            );


        let small = 0;

        let medium = 0;

        let large = 0;


        data.forEach(transaction => {

            const amount =
                Number(
                    transaction.amount || 0
                );


            if (amount <= 5000) {

                small++;

            }

            else if (amount <= 25000) {

                medium++;

            }

            else {

                large++;

            }

        });


        const values = [
            small,
            medium,
            large
        ];


        timeCards.forEach(
            (card, index) => {

                const paragraph =
                    card.querySelector("p");


                if (paragraph) {

                    paragraph.textContent =
                        `${formatNumber(
                            values[index]
                        )} transactions`;

                }

            }
        );

    }


    // =========================================================
    // RECENT FRAUD TRENDS
    // =========================================================

    function updateRecentFraudTrends(data) {

        const analysisBoxes =
            document.querySelectorAll(
                ".analysis-box"
            );


        if (analysisBoxes.length < 6) {

            return;

        }


        // Sixth analysis box = trends

        const trendBox =
            analysisBoxes[5];


        const cards =
            trendBox.querySelectorAll(
                ".time-card"
            );


        let weekendFraud = 0;

        let onlineFraud = 0;


        data.forEach(transaction => {

            if (
                transaction.status !== "FRAUD"
            ) {

                return;

            }


            if (
                String(
                    transaction.created_at || ""
                ).includes("")
            ) {

                // No action needed.
                // Kept intentionally simple.
            }


            // Weekend is not currently stored
            // in database, so we don't invent it.


            if (
                String(
                    transaction.device_type || ""
                ).toLowerCase()
                === "web"
            ) {

                onlineFraud++;

            }

        });


        /*
         * We only update what the current
         * database actually supports.
         */

        if (cards[1]) {

            const paragraph =
                cards[1].querySelector("p");


            if (paragraph) {

                paragraph.textContent =
                    `${onlineFraud} web-based fraud case(s)`;

            }

        }


        if (cards[0]) {

            const paragraph =
                cards[0].querySelector("p");


            if (paragraph) {

                paragraph.textContent =
                    `${weekendFraud} weekend fraud case(s)`;

            }

        }


        if (cards[2]) {

            const paragraph =
                cards[2].querySelector("p");


            if (paragraph) {

                paragraph.textContent =
                    "International transaction data not available.";

            }

        }

    }


    // =========================================================
    // FILTER OPTIONS
    // =========================================================

    function updateFilterOptions(data) {

        const filterBoxes =
            document.querySelectorAll(
                ".filter-box"
            );


        if (filterBoxes.length < 3) {

            return;

        }


        const merchantSelect =
            filterBoxes[1]
                .querySelector("select");


        const riskSelect =
            filterBoxes[2]
                .querySelector("select");


        if (merchantSelect) {

            const merchants =
                [
                    ...new Set(
                        data
                            .map(
                                transaction =>
                                    transaction.merchant
                            )
                            .filter(Boolean)
                    )
                ]
                .sort();


            merchantSelect.innerHTML =
                `<option value="ALL">
                    All Categories
                 </option>`;


            merchants.forEach(
                merchant => {

                    const option =
                        document.createElement(
                            "option"
                        );


                    option.value =
                        merchant;


                    option.textContent =
                        merchant;


                    merchantSelect.appendChild(
                        option
                    );

                }
            );

        }


        if (riskSelect) {

            riskSelect.innerHTML = `

                <option value="ALL">
                    All
                </option>

                <option value="LOW">
                    Low Risk
                </option>

                <option value="MEDIUM">
                    Medium Risk
                </option>

                <option value="HIGH">
                    High Risk
                </option>

            `;

        }

    }


    // =========================================================
    // APPLY FILTER
    // =========================================================

    function applyFilters() {

        const filterBoxes =
            document.querySelectorAll(
                ".filter-box"
            );


        const merchantSelect =
            filterBoxes[1]
                ?.querySelector("select");


        const riskSelect =
            filterBoxes[2]
                ?.querySelector("select");


        const selectedMerchant =
            merchantSelect
                ? merchantSelect.value
                : "ALL";


        const selectedRisk =
            riskSelect
                ? riskSelect.value
                : "ALL";


        const filtered =
            transactions.filter(
                transaction => {

                    const merchantMatch =
                        selectedMerchant === "ALL"
                        ||
                        transaction.merchant ===
                        selectedMerchant;


                    const riskMatch =
                        selectedRisk === "ALL"
                        ||
                        transaction.risk_level ===
                        selectedRisk;


                    return (
                        merchantMatch &&
                        riskMatch
                    );

                }
            );


        updateRiskCards(filtered);

        updateMerchantTable(filtered);

        updateLocationTable(filtered);

        updatePeakFraudHours(filtered);

        updateSpendingPattern(filtered);

        updateRecentFraudTrends(filtered);

    }


    const filterButton =
        document.querySelector(
            ".filter-btn"
        );


    if (filterButton) {

        filterButton.addEventListener(
            "click",
            applyFilters
        );

    }


    // =========================================================
    // HEADER SUMMARY
    // =========================================================

    function updateAnalyticsHeader(
        data
    ) {

        const fraudCount =
            data.filter(
                transaction =>
                    transaction.status ===
                    "FRAUD"
            ).length;


        const paragraph =
            document.querySelector(
                ".analytics-header p"
            );


        if (paragraph) {

            paragraph.textContent =
                `Analyzing ${formatNumber(
                    data.length
                )} recorded transactions with ` +
                `${formatNumber(
                    fraudCount
                )} fraud detection result(s).`;

        }

    }


    // =========================================================
    // HELPERS
    // =========================================================

    function formatNumber(value) {

        return Number(
            value || 0
        ).toLocaleString(
            "en-IN"
        );

    }


    function formatHour(hour) {

        const h =
            Number(hour);


        const suffix =
            h >= 12 ? "PM" : "AM";


        const displayHour =
            h % 12 === 0
                ? 12
                : h % 12;


        return `${String(
            displayHour
        ).padStart(2, "0")}:00 ${suffix}`;

    }


    // =========================================================
    // START
    // =========================================================

    updateFilterOptions();

});