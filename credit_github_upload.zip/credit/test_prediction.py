import requests

url = "http://127.0.0.1:5000/api/predict"

transaction = {
    "amount": 2500,
    "merchant": "Grocery",
    "date": "2026-08-31",
    "time": "14:30",
    "location": "Visakhapatnam",
    "age": 25,
    "gender": "Female",
    "occupation": "Student",
    "income": 30000,
    "card_type": "Classic",
    "device_type": "Mobile",
    "distance": 5
}

response = requests.post(
    url,
    json=transaction
)

print("Status Code:", response.status_code)

print("\nResponse:")

print(response.json())