document.addEventListener("DOMContentLoaded", function () {

    const tableBody = document.querySelector("#historyTable tbody");
    const searchInput = document.getElementById("searchInput");

    let transactions = [];


    // =====================================================
    // LOAD TRANSACTION HISTORY
    // =====================================================

    async function loadHistory() {

        try {

            const response = await fetch(
                "/api/history?limit=100"
            );

            const result = await response.json();

            if (!response.ok || !result.success) {

                throw new Error(
                    result.error || "Unable to load transaction history."
                );

            }

            transactions = result.data || [];

            displayTransactions(transactions);

        } catch (error) {

            console.error(
                "History loading error:",
                error
            );

            tableBody.innerHTML = `
                <tr>
                    <td colspan="8">
                        Unable to load transaction history.
                    </td>
                </tr>
            `;

        }
    }


    // =====================================================
    // DISPLAY TRANSACTIONS
    // =====================================================

    function displayTransactions(data) {

        tableBody.innerHTML = "";


        if (data.length === 0) {

            tableBody.innerHTML = `
                <tr>
                    <td colspan="8">
                        No transactions found.
                    </td>
                </tr>
            `;

            return;
        }


        data.forEach(transaction => {

            const row = document.createElement("tr");


            const statusClass =
                transaction.status === "FRAUD"
                    ? "fraud"
                    : transaction.suspicious_flag === "SUSPICIOUS"
                        ? "suspicious"
                        : "genuine";


            row.innerHTML = `

                <td>
                    TXN${String(transaction.id).padStart(6, "0")}
                </td>

                <td>
                    ₹${Number(
                        transaction.amount || 0
                    ).toLocaleString("en-IN")}
                </td>

                <td>
                    ${transaction.merchant || "-"}
                </td>

                <td>
                    ${transaction.customer_occupation || "-"}
                </td>

                <td>
                    ${transaction.location || "-"}
                </td>

                <td>
                    ${transaction.transaction_time || "-"}
                </td>

                <td class="${statusClass}">
                    ${transaction.status || "-"}
                </td>

                <td>
                    ${Number(
                        transaction.risk_score || 0
                    ).toFixed(2)}%
                </td>

            `;


            tableBody.appendChild(row);

        });

    }


    // =====================================================
    // SEARCH
    // =====================================================

    searchInput.addEventListener(
        "input",
        function () {

            const searchText =
                this.value
                    .toLowerCase()
                    .trim();


            const filtered =
                transactions.filter(transaction => {

                    const transactionId =
                        `txn${String(
                            transaction.id
                        ).padStart(6, "0")}`;


                    return (

                        transactionId
                            .toLowerCase()
                            .includes(searchText)

                        ||

                        String(
                            transaction.merchant || ""
                        )
                            .toLowerCase()
                            .includes(searchText)

                        ||

                        String(
                            transaction.location || ""
                        )
                            .toLowerCase()
                            .includes(searchText)

                        ||

                        String(
                            transaction.status || ""
                        )
                            .toLowerCase()
                            .includes(searchText)

                    );

                });


            displayTransactions(filtered);

        }
    );


    // =====================================================
    // INITIAL LOAD
    // =====================================================

    loadHistory();

});