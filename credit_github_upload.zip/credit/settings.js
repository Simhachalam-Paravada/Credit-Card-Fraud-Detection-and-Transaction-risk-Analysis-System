/* =========================================================
        SETTINGS.JS
        CREDIT CARD FRAUD DETECTION SYSTEM
========================================================= */


document.addEventListener(
    "DOMContentLoaded",
    () => {

        console.log(
            "Settings Page Loaded"
        );


        loadLoggedInUser();

        initializePreferences();

        bindEditProfile();

        bindSaveSettings();

        bindCardHover();

        bindInputFocus();

        bindButtonEffect();

    }
);


/* =========================================================
        GET LOGGED-IN USER
========================================================= */

function getLoggedInUsername() {

    let username =
        sessionStorage.getItem(
            "username"
        );


    if (!username) {

        username =
            localStorage.getItem(
                "username"
            );

    }


    if (!username) {

        username =
            "Admin User";

    }


    return username.trim();

}


/* =========================================================
        LOAD USER
========================================================= */

function loadLoggedInUser() {

    const username =
        getLoggedInUsername();


    const role =
        "Fraud Analyst";


    /* Top profile */

    const topName =
        document.getElementById(
            "topProfileName"
        );


    if (topName) {

        topName.textContent =
            username;

    }


    /* Main profile */

    const profileName =
        document.getElementById(
            "profileName"
        );


    if (profileName) {

        profileName.textContent =
            username;

    }


    /* Account full name */

    const fullNameInput =
        document.querySelector(
            ".account-card .input-group input"
        );


    if (fullNameInput) {

        fullNameInput.value =
            username;

    }


    console.log(
        "Logged-in user:",
        username
    );

}


/* =========================================================
        INITIALIZE PREFERENCES
========================================================= */

function initializePreferences() {


    /* -----------------------------------------
            DARK MODE
    ----------------------------------------- */

    const darkMode =
        document.getElementById(
            "darkMode"
        );


    const savedDarkMode =
        localStorage.getItem(
            "ccfd_dark_mode"
        );


    if (darkMode) {

        if (savedDarkMode === "true") {

            darkMode.checked =
                true;

            applyDarkMode(true);

        }
        else {

            darkMode.checked =
                false;

        }


        darkMode.addEventListener(
            "change",
            () => {

                applyDarkMode(
                    darkMode.checked
                );

                localStorage.setItem(
                    "ccfd_dark_mode",
                    darkMode.checked
                );

            }
        );

    }



    /* -----------------------------------------
            FRAUD ALERTS
    ----------------------------------------- */

    const fraudAlerts =
        document.getElementById(
            "fraudAlerts"
        );


    const savedAlerts =
        localStorage.getItem(
            "ccfd_fraud_alerts"
        );


    if (fraudAlerts) {

        if (savedAlerts !== null) {

            fraudAlerts.checked =
                savedAlerts === "true";

        }


        fraudAlerts.addEventListener(
            "change",
            () => {

                localStorage.setItem(
                    "ccfd_fraud_alerts",
                    fraudAlerts.checked
                );

            }
        );

    }

}


/* =========================================================
        DARK MODE
========================================================= */

function applyDarkMode(
    enabled
) {

    if (!enabled) {

        document.body.style.background =
            "#f3f6fa";

        document.body.style.color =
            "#24344d";

        return;

    }


    document.body.style.background =
        "#111827";

    document.body.style.color =
        "#ffffff";

}


/* =========================================================
        EDIT PROFILE
========================================================= */

function bindEditProfile() {

    const editBtn =
        document.querySelector(
            ".edit-btn"
        );


    if (!editBtn) return;


    editBtn.addEventListener(
        "click",
        () => {

            const fields =
                document.querySelectorAll(
                    ".account-card .input-group input"
                );


            fields.forEach(
                (field) => {

                    if (
                        !field.readOnly
                    ) {

                        field.readOnly =
                            false;

                    }

                }
            );


            editBtn.innerHTML = `
                <i class="fa-solid fa-check"></i>
                Profile Editing
            `;


            editBtn.style.background =
                "#16a34a";

        }
    );

}


/* =========================================================
        SAVE SETTINGS
========================================================= */

function bindSaveSettings() {

    const saveBtn =
        document.querySelector(
            ".save-btn"
        );


    if (!saveBtn) return;


    saveBtn.addEventListener(
        "click",
        () => {

            const darkMode =
                document.getElementById(
                    "darkMode"
                );


            const fraudAlerts =
                document.getElementById(
                    "fraudAlerts"
                );


            if (darkMode) {

                localStorage.setItem(
                    "ccfd_dark_mode",
                    darkMode.checked
                );

            }


            if (fraudAlerts) {

                localStorage.setItem(
                    "ccfd_fraud_alerts",
                    fraudAlerts.checked
                );

            }


            saveBtn.innerHTML = `
                <i class="fa-solid fa-check"></i>
                Saved Successfully
            `;


            saveBtn.style.background =
                "#16a34a";


            setTimeout(
                () => {

                    saveBtn.innerHTML = `
                        <i class="fa-solid fa-floppy-disk"></i>
                        Save Changes
                    `;

                    saveBtn.style.background =
                        "#2563eb";

                },
                1800
            );

        }
    );

}


/* =========================================================
        CARD HOVER
========================================================= */

function bindCardHover() {

    const cards =
        document.querySelectorAll(
            ".profile-card," +
            ".account-card," +
            ".preference-card," +
            ".info-card"
        );


    cards.forEach(
        (card) => {

            card.addEventListener(
                "mouseenter",
                () => {

                    card.style.transform =
                        "translateY(-3px)";

                }
            );


            card.addEventListener(
                "mouseleave",
                () => {

                    card.style.transform =
                        "translateY(0)";

                }
            );

        }
    );

}


/* =========================================================
        INPUT FOCUS
========================================================= */

function bindInputFocus() {

    const fields =
        document.querySelectorAll(
            "input"
        );


    fields.forEach(
        (field) => {

            field.addEventListener(
                "focus",
                () => {

                    if (
                        !field.readOnly
                    ) {

                        field.style.boxShadow =
                            "0 0 0 3px rgba(37,99,235,.08)";

                    }

                }
            );


            field.addEventListener(
                "blur",
                () => {

                    field.style.boxShadow =
                        "none";

                }
            );

        }
    );

}


/* =========================================================
        BUTTON EFFECT
========================================================= */

function bindButtonEffect() {

    const buttons =
        document.querySelectorAll(
            ".save-btn," +
            ".edit-btn"
        );


    buttons.forEach(
        (button) => {

            button.addEventListener(
                "mousedown",
                () => {

                    button.style.transform =
                        "scale(.97)";

                }
            );


            button.addEventListener(
                "mouseup",
                () => {

                    button.style.transform =
                        "scale(1)";

                }
            );

        }
    );

}


/* =========================================================
        PAGE READY
========================================================= */

window.addEventListener(
    "load",
    () => {

        console.log(
            "CCFD Settings Ready"
        );

    }
);