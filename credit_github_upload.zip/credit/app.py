from pathlib import Path
from datetime import datetime
import sqlite3

import joblib
import pandas as pd

from flask import Flask, jsonify, request, send_from_directory, send_file
from flask_cors import CORS


# ============================================================
# 1. PROJECT PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

PROJECT_DIR = BASE_DIR.parent

MAIN_DIR = PROJECT_DIR.parent

CREDIT_CARD_DIR = PROJECT_DIR / "Credit_card"

DATASET_DIR = CREDIT_CARD_DIR / "dataset"

MODEL_DIR = CREDIT_CARD_DIR / "model"

MODEL_PATH = MODEL_DIR / "fraud_detection_model.pkl"

FEATURE_PATH = MODEL_DIR / "feature_names.pkl"

DATABASE_PATH = BASE_DIR / "fraud_history.db"

FRONTEND_DIR = (
    MAIN_DIR
    / "Frontend"
    / "CreditCardFraudDetection"
    / "CreditCardFraudDetection"
    / "frontend"
)


# ============================================================
# 2. FLASK APPLICATION
# ============================================================

app = Flask(
    __name__,
    static_folder=str(FRONTEND_DIR),
    static_url_path=""
)

CORS(app)


# ============================================================
# 3. LOAD MODEL
# ============================================================

if not MODEL_PATH.exists():

    raise FileNotFoundError(
        f"Model file not found:\n{MODEL_PATH}"
    )

print("\nLoading trained fraud detection model...")

model = joblib.load(MODEL_PATH)

print("Model loaded successfully.")


# ============================================================
# 4. LOAD FEATURE NAMES
# ============================================================

if not FEATURE_PATH.exists():

    raise FileNotFoundError(
        f"Feature names file not found:\n{FEATURE_PATH}"
    )

feature_names = joblib.load(FEATURE_PATH)

print("\nModel features:")

for feature in feature_names:

    print(" -", feature)


# ============================================================
# 5. LOAD CLEANED DATASET
# ============================================================

DATASET_PATH = (
    DATASET_DIR
    / "Cleaned_Credit-Card-Fraud_Dataset.csv"
)

if not DATASET_PATH.exists():

    raise FileNotFoundError(
        f"Cleaned dataset not found:\n{DATASET_PATH}"
    )

print("\nLoading cleaned dataset...")

reference_df = pd.read_csv(DATASET_PATH)

print(
    f"Dataset loaded: {reference_df.shape[0]} rows, "
    f"{reference_df.shape[1]} columns"
)


# ============================================================
# 6. DATABASE
# ============================================================

def initialize_database():

    with sqlite3.connect(DATABASE_PATH) as connection:

        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS predictions (

                id INTEGER PRIMARY KEY AUTOINCREMENT,

                created_at TEXT NOT NULL,

                amount REAL NOT NULL,

                merchant TEXT NOT NULL,

                transaction_date TEXT NOT NULL,

                transaction_time TEXT NOT NULL,

                location TEXT NOT NULL,

                customer_age INTEGER NOT NULL,

                customer_gender TEXT NOT NULL,

                customer_occupation TEXT NOT NULL,

                customer_income REAL NOT NULL,

                card_type TEXT NOT NULL,

                device_type TEXT NOT NULL,

                transaction_distance REAL NOT NULL,

                prediction INTEGER NOT NULL,

                status TEXT NOT NULL,

                fraud_probability REAL NOT NULL,

                risk_score REAL NOT NULL,

                risk_level TEXT NOT NULL,

                suspicious_flag TEXT NOT NULL

            )
            """
        )

        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
            """
        )

        existing_user = connection.execute(
            """
            SELECT id
            FROM users
            WHERE username = ?
            """,
            ("admin",)
        ).fetchone()

        if existing_user is None:
            connection.execute(
                """
                INSERT INTO users (
                    username,
                    password
                )
                VALUES (?, ?)
                """,
                ("admin", "admin123")
            )

        connection.commit()


initialize_database()


# ============================================================
# 7. VALIDATION HELPERS
# ============================================================

def validate_category(value, column_name):

    valid_values = (
        reference_df[column_name]
        .dropna()
        .astype(str)
        .unique()
        .tolist()
    )

    value = str(value).strip()

    matched_value = next(
        (
            item
            for item in valid_values
            if item.lower() == value.lower()
        ),
        None
    )

    if matched_value is None:

        raise ValueError(
            f"Invalid {column_name}. "
            f"Allowed values: {', '.join(valid_values)}"
        )

    return matched_value


# ============================================================
# 8. GET LOCATION COORDINATES
# ============================================================

def get_location_coordinates(location):

    matched = reference_df[
        reference_df["Transaction_Location"]
        .astype(str)
        .str.lower()
        == location.lower()
    ]

    if matched.empty:

        raise ValueError(
            f"Location '{location}' not found "
            "in training dataset."
        )

    latitude = matched["Latitude"].mean()

    longitude = matched["Longitude"].mean()

    return float(latitude), float(longitude)


# ============================================================
# 9. BUILD MODEL INPUT
# ============================================================

def build_model_input(data):

    # --------------------------------------------------------
    # Required frontend inputs
    # --------------------------------------------------------

    required_fields = [

        "amount",
        "merchant",
        "date",
        "time",
        "location",
        "age",
        "gender",
        "occupation",
        "income",
        "card_type",
        "device_type",
        "distance"

    ]


    missing_fields = [

        field

        for field in required_fields

        if field not in data
        or data[field] in (None, "")

    ]


    if missing_fields:

        raise ValueError(
            "Missing required fields: "
            + ", ".join(missing_fields)
        )


    # --------------------------------------------------------
    # Numeric inputs
    # --------------------------------------------------------

    try:

        amount = float(data["amount"])

        age = int(data["age"])

        income = float(data["income"])

        distance = float(data["distance"])

    except ValueError:

        raise ValueError(
            "Amount, age, income and distance "
            "must contain valid numbers."
        )


    # --------------------------------------------------------
    # Numeric validation
    # --------------------------------------------------------

    if amount <= 0:

        raise ValueError(
            "Transaction amount must be greater than 0."
        )


    if age <= 0 or age > 120:

        raise ValueError(
            "Customer age must be between 1 and 120."
        )


    if income <= 0:

        raise ValueError(
            "Customer income must be greater than 0."
        )


    if distance < 0:

        raise ValueError(
            "Transaction distance cannot be negative."
        )


    # --------------------------------------------------------
    # Categorical inputs
    # --------------------------------------------------------

    merchant = validate_category(
        data["merchant"],
        "Merchant_Category"
    )

    location = validate_category(
        data["location"],
        "Transaction_Location"
    )

    gender = validate_category(
        data["gender"],
        "Customer_Gender"
    )

    occupation = validate_category(
        data["occupation"],
        "Customer_Occupation"
    )

    card_type = validate_category(
        data["card_type"],
        "Card_Type"
    )

    device_type = validate_category(
        data["device_type"],
        "Device_Type"
    )


    # --------------------------------------------------------
    # Date + time
    # --------------------------------------------------------

    try:

        transaction_datetime = datetime.strptime(

            f"{data['date']} {data['time']}",

            "%Y-%m-%d %H:%M"

        )

    except ValueError:

        raise ValueError(
            "Invalid date/time. "
            "Use YYYY-MM-DD and HH:MM format."
        )


    transaction_hour = (
        transaction_datetime.hour
    )


    # --------------------------------------------------------
    # Derived features
    # --------------------------------------------------------

    is_night = int(

        transaction_hour < 6
        or transaction_hour >= 18

    )


    is_weekend = int(

        transaction_datetime.weekday() >= 5

    )


    latitude, longitude = (
        get_location_coordinates(location)
    )


    amount_income_ratio = (
        amount / income
    )


    amount_distance_ratio = (
        amount / (distance + 1)
    )


    # --------------------------------------------------------
    # Create all 17 model features
    # --------------------------------------------------------

    transaction = {

        "Transaction_Amount":
            amount,

        "Merchant_Category":
            merchant,

        "Transaction_Location":
            location,

        "Latitude":
            latitude,

        "Longitude":
            longitude,

        "Customer_Age":
            age,

        "Customer_Gender":
            gender,

        "Customer_Occupation":
            occupation,

        "Customer_Income":
            income,

        "Card_Type":
            card_type,

        "Device_Type":
            device_type,

        "Transaction_Distance":
            distance,

        "Transaction_Hour":
            transaction_hour,

        "Is_Night":
            is_night,

        "Is_Weekend":
            is_weekend,

        "Amount_Income_Ratio":
            amount_income_ratio,

        "Amount_Distance_Ratio":
            amount_distance_ratio

    }


    X = pd.DataFrame(
        [transaction]
    )


    # --------------------------------------------------------
    # Ensure exact training feature order
    # --------------------------------------------------------

    missing_features = [

        feature

        for feature in feature_names

        if feature not in X.columns

    ]


    if missing_features:

        raise ValueError(
            "Missing model features: "
            + ", ".join(missing_features)
        )


    X = X[
        feature_names
    ]


    return X


# ============================================================
# 10. RISK ANALYSIS
# ============================================================

def calculate_risk(
    prediction,
    fraud_probability
):

    risk_score = round(
        fraud_probability * 100,
        2
    )


    if risk_score >= 70:

        risk_level = "HIGH"

    elif risk_score >= 40:

        risk_level = "MEDIUM"

    else:

        risk_level = "LOW"


    if prediction == 1:

        status = "FRAUD"

    else:

        status = "GENUINE"


    if (
        prediction == 1
        or risk_score >= 70
    ):

        suspicious_flag = "SUSPICIOUS"

    elif risk_score >= 40:

        suspicious_flag = "REVIEW"

    else:

        suspicious_flag = "NORMAL"


    return (
        status,
        risk_score,
        risk_level,
        suspicious_flag
    )


# ============================================================
# 11. HOME PAGE
# ============================================================

# ============================================================
# 11. HOME PAGE
# ============================================================

@app.route("/")
def home():
    if (
        FRONTEND_DIR.exists()
        and (FRONTEND_DIR / "login.html").exists()
    ):
        return send_from_directory(
            FRONTEND_DIR,
            "login.html"
        )

    return jsonify({
        "success": True,
        "message":
            "Credit Card Fraud Detection Backend is running."
    })

# ============================================================
# 12. FRONTEND FILES
# ============================================================

@app.route("/<path:path>")
def serve_frontend(path):

    requested_file = (
        FRONTEND_DIR / path
    )


    if (
        requested_file.exists()
        and requested_file.is_file()
    ):

        return send_from_directory(
            FRONTEND_DIR,
            path
        )


    return jsonify({

        "success": False,

        "error":
            "Requested resource not found."

    }), 404


# ============================================================
# 13. HEALTH CHECK
# ============================================================

@app.route(
    "/api/health",
    methods=["GET"]
)
def health_check():

    return jsonify({

        "success": True,

        "message":
            "Credit Card Fraud Detection Backend is running.",

        "model_loaded":
            model is not None,

        "dataset_loaded":
            reference_df is not None,

        "feature_count":
            len(feature_names)

    })
# ============================================================
# LOGIN API
# ============================================================

# ============================================================
# LOGIN API
# ============================================================

@app.route("/api/login", methods=["POST"])
def login():

    try:
        data = request.get_json(silent=True)

        if not data:
            return jsonify({
                "success": False,
                "error": "JSON request body is required."
            }), 400

        username = str(
            data.get("username", "")
        ).strip()

        password = str(
            data.get("password", "")
        )

        # Demo login:
        # Any non-empty username and password are accepted.
        if username and password:
            return jsonify({
                "success": True,
                "message": "Login successful.",
                "username": username
            })

        return jsonify({
            "success": False,
            "error": "Username and password are required."
        }), 400

    except Exception as error:
        print("\nLogin error:", error)

        return jsonify({
            "success": False,
            "error": str(error)
        }), 500
    
# ============================================================
# 14. PREDICTION API
# ============================================================

@app.route(
    "/api/predict",
    methods=["POST"]
)
def predict_transaction():

    try:

        data = request.get_json(
            silent=True
        )


        if not data:

            return jsonify({

                "success": False,

                "error":
                    "JSON request body is required."

            }), 400


        print("\nIncoming transaction:")

        print(data)


        # ----------------------------------------------------
        # Build model input
        # ----------------------------------------------------

        X = build_model_input(data)


        print("\nModel input:")

        print(X)


        # ----------------------------------------------------
        # Prediction
        # ----------------------------------------------------

        prediction = int(
            model.predict(X)[0]
        )


        # ----------------------------------------------------
        # Fraud probability
        # ----------------------------------------------------

        if hasattr(
            model,
            "predict_proba"
        ):

            probabilities = (
                model.predict_proba(X)[0]
            )


            classes = list(
                model.classes_
            )


            if 1 in classes:

                fraud_index = (
                    classes.index(1)
                )

                fraud_probability = float(
                    probabilities[
                        fraud_index
                    ]
                )

            else:

                fraud_probability = 0.0


        else:

            fraud_probability = (

                1.0
                if prediction == 1
                else 0.0

            )


        # ----------------------------------------------------
        # Risk analysis
        # ----------------------------------------------------

        (
            status,
            risk_score,
            risk_level,
            suspicious_flag

        ) = calculate_risk(

            prediction,
            fraud_probability

        )


        # ----------------------------------------------------
        # Save transaction
        # ----------------------------------------------------

        created_at = datetime.now().isoformat(
            timespec="seconds"
        )


        with sqlite3.connect(
            DATABASE_PATH
        ) as connection:

            cursor = connection.execute(

                """
                INSERT INTO predictions (

                    created_at,
                    amount,
                    merchant,
                    transaction_date,
                    transaction_time,
                    location,
                    customer_age,
                    customer_gender,
                    customer_occupation,
                    customer_income,
                    card_type,
                    device_type,
                    transaction_distance,
                    prediction,
                    status,
                    fraud_probability,
                    risk_score,
                    risk_level,
                    suspicious_flag

                )

                VALUES (
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?, ?
                )
                """,

                (

                    created_at,

                    float(data["amount"]),

                    str(data["merchant"]),

                    str(data["date"]),

                    str(data["time"]),

                    str(data["location"]),

                    int(data["age"]),

                    str(data["gender"]),

                    str(data["occupation"]),

                    float(data["income"]),

                    str(data["card_type"]),

                    str(data["device_type"]),

                    float(data["distance"]),

                    prediction,

                    status,

                    round(
                        fraud_probability * 100,
                        2
                    ),

                    risk_score,

                    risk_level,

                    suspicious_flag

                )

            )


            prediction_id = (
                cursor.lastrowid
            )


            connection.commit()


        # ----------------------------------------------------
        # API response
        # ----------------------------------------------------

        return jsonify({

            "success": True,

            "prediction_id":
                prediction_id,

            "prediction":
                status,

            "fraud_probability":
                round(
                    fraud_probability * 100,
                    2
                ),

            "risk_score":
                risk_score,

            "risk_level":
                risk_level,

            "suspicious_flag":
                suspicious_flag,

            "message":

                (
                    "Suspicious transaction detected."
                    if suspicious_flag
                    == "SUSPICIOUS"

                    else
                    "Transaction appears normal."
                )

        })


    except Exception as error:

        print(
            "\nPrediction error:",
            error
        )


        return jsonify({

            "success": False,

            "error":
                str(error)

        }), 400


# ============================================================
# 15. HISTORY API
# ============================================================

@app.route(
    "/api/history",
    methods=["GET"]
)
def get_history():

    try:

        limit = request.args.get(
            "limit",
            default=100,
            type=int
        )


        limit = max(
            1,
            min(limit, 500)
        )


        with sqlite3.connect(
            DATABASE_PATH
        ) as connection:

            connection.row_factory = (
                sqlite3.Row
            )


            rows = connection.execute(

                """
                SELECT *

                FROM predictions

                ORDER BY id DESC

                LIMIT ?
                """,

                (limit,)

            ).fetchall()


        transactions = [

            dict(row)

            for row in rows

        ]


        return jsonify({

            "success": True,

            "count":
                len(transactions),

            "data":
                transactions

        })


    except Exception as error:

        return jsonify({

            "success": False,

            "error":
                str(error)

        }), 500

# ============================================================
# 16. LOCATION MAP API
# ============================================================

@app.route(
    "/api/locations",
    methods=["GET"]
)
def get_location_data():

    try:

        limit = request.args.get(
            "limit",
            default=500,
            type=int
        )

        limit = max(
            1,
            min(limit, 500)
        )


        with sqlite3.connect(
            DATABASE_PATH
        ) as connection:

            connection.row_factory = (
                sqlite3.Row
            )

            rows = connection.execute(

                """
                SELECT
                    id,
                    amount,
                    merchant,
                    location,
                    transaction_date,
                    transaction_time,
                    status,
                    risk_score,
                    risk_level,
                    suspicious_flag

                FROM predictions

                ORDER BY id DESC

                LIMIT ?
                """,

                (limit,)

            ).fetchall()


        # Cache coordinates so the same
        # location is not calculated repeatedly

        location_cache = {}

        map_data = []


        for row in rows:

            location = str(
                row["location"] or ""
            ).strip()


            if not location:
                continue


            # --------------------------------------------
            # Get coordinates
            # --------------------------------------------

            if location not in location_cache:

                try:

                    latitude, longitude = (
                        get_location_coordinates(
                            location
                        )
                    )

                    location_cache[location] = (
                        latitude,
                        longitude
                    )

                except Exception:

                    # Skip locations for which
                    # coordinates cannot be found

                    continue


            latitude, longitude = (
                location_cache[location]
            )


            # --------------------------------------------
            # Build map marker data
            # --------------------------------------------

            map_data.append({

                "id":
                    row["id"],

                "amount":
                    row["amount"],

                "merchant":
                    row["merchant"],

                "location":
                    location,

                "transaction_date":
                    row["transaction_date"],

                "transaction_time":
                    row["transaction_time"],

                "status":
                    row["status"],

                "risk_score":
                    row["risk_score"],

                "risk_level":
                    row["risk_level"],

                "suspicious_flag":
                    row["suspicious_flag"],

                "latitude":
                    latitude,

                "longitude":
                    longitude

            })


        return jsonify({

            "success":
                True,

            "count":
                len(map_data),

            "data":
                map_data

        })


    except Exception as error:

        print(
            "\nLocation API error:",
            error
        )


        return jsonify({

            "success":
                False,

            "error":
                str(error)

        }), 500
# ============================================================
# 16. ANALYTICS API
# ============================================================

@app.route(
    "/api/analytics",
    methods=["GET"]
)
def get_analytics():

    try:

        with sqlite3.connect(
            DATABASE_PATH
        ) as connection:

            result = connection.execute(

                """
                SELECT

                    COUNT(*) AS total,

                    COALESCE(
                        SUM(
                            CASE
                                WHEN prediction = 1
                                THEN 1
                                ELSE 0
                            END
                        ),
                        0
                    ) AS fraud,

                    COALESCE(
                        SUM(
                            CASE
                                WHEN prediction = 0
                                THEN 1
                                ELSE 0
                            END
                        ),
                        0
                    ) AS genuine,

                    COALESCE(
                        AVG(risk_score),
                        0
                    ) AS average_risk

                FROM predictions
                """
            ).fetchone()


        total = result[0]

        fraud = result[1]

        genuine = result[2]

        average_risk = result[3]


        fraud_rate = (

            round(
                (fraud / total) * 100,
                2
            )

            if total > 0

            else 0

        )


        return jsonify({

            "success": True,

            "total_predictions":
                total,

            "fraud_predictions":
                fraud,

            "genuine_predictions":
                genuine,

            "fraud_rate":
                fraud_rate,

            "average_risk_score":
                round(
                    average_risk,
                    2
                )

        })


    except Exception as error:

        return jsonify({

            "success": False,

            "error":
                str(error)

        }), 500
    # =========================================================
# PDF REPORT DOWNLOAD
# =========================================================

@app.route("/api/report/pdf", methods=["GET"])
def download_report_pdf():

    try:

        import io

        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import (
            SimpleDocTemplate,
            Table,
            TableStyle,
            Paragraph,
            Spacer
        )


        # ---------------------------------------------
        # Connect to database
        # ---------------------------------------------

        conn = sqlite3.connect(DATABASE_PATH)

        cursor = conn.cursor()


        # ---------------------------------------------
        # Get transaction records
        # ---------------------------------------------

        cursor.execute("""
            SELECT
                id,
                transaction_date,
                amount,
                merchant,
                location,
                risk_score,
                status
            FROM predictions
            ORDER BY id DESC
        """)

        rows = cursor.fetchall()

        conn.close()


        # ---------------------------------------------
        # Create PDF in memory
        # ---------------------------------------------

        pdf_buffer = io.BytesIO()


        document = SimpleDocTemplate(
            pdf_buffer,
            pagesize=A4,
            rightMargin=30,
            leftMargin=30,
            topMargin=30,
            bottomMargin=30
        )


        styles = getSampleStyleSheet()

        story = []


        # ---------------------------------------------
        # Title
        # ---------------------------------------------

        title = Paragraph(
            "<b>Credit Card Fraud Detection & "
            "Transaction Risk Analysis Report</b>",
            styles["Title"]
        )

        story.append(title)

        story.append(Spacer(1, 15))


        # ---------------------------------------------
        # Summary
        # ---------------------------------------------

        total = len(rows)

        fraud = sum(
            1
            for row in rows
            if str(row[6]).upper() == "FRAUD"
        )

        genuine = total - fraud


        fraud_rate = (
            (fraud / total) * 100
            if total > 0
            else 0
        )


        summary_text = (
            f"<b>Total Transactions:</b> {total}<br/>"
            f"<b>Fraud Transactions:</b> {fraud}<br/>"
            f"<b>Genuine Transactions:</b> {genuine}<br/>"
            f"<b>Fraud Rate:</b> {fraud_rate:.2f}%"
        )


        story.append(
            Paragraph(
                summary_text,
                styles["Normal"]
            )
        )


        story.append(Spacer(1, 20))


        # ---------------------------------------------
        # Table data
        # ---------------------------------------------

        table_data = [

            [
                "ID",
                "Date",
                "Amount",
                "Merchant",
                "Location",
                "Risk",
                "Status"
            ]

        ]


        for row in rows:

            table_data.append(

                [

                    f"TXN{row[0]:06d}",

                    row[1] or "-",

                    f"₹{float(row[2] or 0):,.2f}",

                    str(row[3] or "-"),

                    str(row[4] or "-"),

                    f"{float(row[5] or 0):.2f}%",

                    str(row[6] or "-")

                ]

            )


        # ---------------------------------------------
        # Create table
        # ---------------------------------------------

        table = Table(
            table_data,
            repeatRows=1,
            colWidths=[
                55,
                70,
                75,
                85,
                75,
                55,
                60
            ]
        )


        table.setStyle(

            TableStyle(

                [

                    (
                        "BACKGROUND",
                        (0, 0),
                        (-1, 0),
                        colors.HexColor("#1f4e78")
                    ),

                    (
                        "TEXTCOLOR",
                        (0, 0),
                        (-1, 0),
                        colors.white
                    ),

                    (
                        "FONTNAME",
                        (0, 0),
                        (-1, 0),
                        "Helvetica-Bold"
                    ),

                    (
                        "FONTSIZE",
                        (0, 0),
                        (-1, -1),
                        7
                    ),

                    (
                        "GRID",
                        (0, 0),
                        (-1, -1),
                        0.5,
                        colors.grey
                    ),

                    (
                        "ALIGN",
                        (0, 0),
                        (-1, -1),
                        "CENTER"
                    ),

                    (
                        "VALIGN",
                        (0, 0),
                        (-1, -1),
                        "MIDDLE"
                    ),

                    (
                        "BOTTOMPADDING",
                        (0, 0),
                        (-1, 0),
                        8
                    ),

                    (
                        "TOPPADDING",
                        (0, 0),
                        (-1, 0),
                        8
                    )

                ]

            )

        )


        story.append(table)


        # ---------------------------------------------
        # Build PDF
        # ---------------------------------------------

        document.build(story)


        pdf_buffer.seek(0)


        # ---------------------------------------------
        # Send PDF to browser
        # ---------------------------------------------

        return send_file(

            pdf_buffer,

            mimetype="application/pdf",

            as_attachment=True,

            download_name=
                "fraud_transaction_report.pdf"

        )


    except Exception as error:

        return jsonify({

            "success": False,

            "error": str(error)

        }), 500


# ============================================================
# 17. RUN APPLICATION
# ============================================================

if __name__ == "__main__":

    print(
        "\n=============================================="
    )

    print(
        " CREDIT CARD FRAUD DETECTION SYSTEM"
    )

    print(
        "=============================================="
    )

    print(
        "\nBackend URL:"
    )

    print(
        "http://127.0.0.1:5000"
    )

    print(
        "\nHealth Check:"
    )

    print(
        "http://127.0.0.1:5000/api/health"
    )

    print(
        "\n17 model features loaded."
    )

    app.run(

        host="127.0.0.1",

        port=5000,

        debug=True

    )