document.addEventListener("DOMContentLoaded", function () {

    const loginForm =
        document.getElementById("loginForm");


    loginForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            const username =
                document.getElementById(
                    "username"
                ).value.trim();


            const password =
                document.getElementById(
                    "password"
                ).value;


            if (!username || !password) {

                alert(
                    "Please enter username and password."
                );

                return;

            }


            try {

                const response =
                    await fetch(
                        "/api/login",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body: JSON.stringify({
                                username:
                                    username,

                                password:
                                    password
                            })
                        }
                    );


                const result =
                    await response.json();


                if (
                    response.ok &&
                    result.success
                ) {

                    // Save login state
                    sessionStorage.setItem(
                        "loggedIn",
                        "true"
                    );


                    sessionStorage.setItem(
                        "username",
                        username
                    );


                    window.location.href =
                        "home.html";

                }

                else {

                    alert(
                        result.error ||
                        "Invalid username or password."
                    );

                }

            }

            catch (error) {

                console.error(
                    "Login error:",
                    error
                );


                alert(
                    "Unable to connect to the server."
                );

            }

        }
    );

});