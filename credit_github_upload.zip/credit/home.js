/* =========================================================
   CREDIT CARD FRAUD DETECTION
   HOME PAGE JAVASCRIPT
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       USER
       ===================================================== */

    const username =
        sessionStorage.getItem("username") ||
        localStorage.getItem("username") ||
        "Devi";

    const welcomeUsername =
        document.getElementById("welcomeUsername");

    const topUsername =
        document.getElementById("topUsername");

    const profileAvatar =
        document.getElementById("profileAvatar");


    if (welcomeUsername) {
        welcomeUsername.textContent = username;
    }

    if (topUsername) {
        topUsername.textContent = username;
    }

    if (profileAvatar) {
        profileAvatar.textContent =
            username.charAt(0).toUpperCase();
    }


    /* =====================================================
       NAVIGATION
       ===================================================== */

    const startPredictionBtn =
        document.getElementById("startPredictionBtn");

    const dashboardBtn =
        document.getElementById("dashboardBtn");


    if (startPredictionBtn) {
        startPredictionBtn.addEventListener("click", () => {
            window.location.href = "predict.html";
        });
    }


    if (dashboardBtn) {
        dashboardBtn.addEventListener("click", () => {
            window.location.href = "dashboard.html";
        });
    }


    /* =====================================================
       LOGOUT
       ===================================================== */

    const logoutBtn =
        document.getElementById("logoutBtn");

    if (logoutBtn) {

        logoutBtn.addEventListener("click", () => {

            sessionStorage.removeItem("username");
            localStorage.removeItem("username");

            window.location.href = "login.html";
        });

    }


    /* =====================================================
       STATUS ELEMENTS
       ===================================================== */

    const apiStatus =
        document.getElementById("apiStatus");

    const apiDot =
        document.getElementById("apiDot");

    const modelStatus =
        document.getElementById("modelStatus");

    const modelDot =
        document.getElementById("modelDot");

    const databaseStatus =
        document.getElementById("databaseStatus");

    const databaseDot =
        document.getElementById("databaseDot");


    /* =====================================================
       STATUS HELPERS
       ===================================================== */

    function setOnline(element, dot, message) {

        if (element) {
            element.textContent = message;
        }

        if (dot) {
            dot.classList.remove("offline");
            dot.classList.add("online");
        }
    }


    function setOffline(element, dot, message) {

        if (element) {
            element.textContent = message;
        }

        if (dot) {
            dot.classList.remove("online");
            dot.classList.add("offline");
        }
    }


    /* =====================================================
       CHECK FLASK API + ML MODEL
       ===================================================== */

    async function checkSystemHealth() {

        try {

            const response =
                await fetch("/api/health", {
                    method: "GET"
                });

            if (!response.ok) {
                throw new Error("Health API failed");
            }

            const data =
                await response.json();


            /* ---------------- Flask API ---------------- */

            setOnline(
                apiStatus,
                apiDot,
                "Running"
            );


            /* ---------------- ML Model ---------------- */

            if (data.model_loaded === true) {

                setOnline(
                    modelStatus,
                    modelDot,
                    "Loaded"
                );

            } else {

                setOffline(
                    modelStatus,
                    modelDot,
                    "Unavailable"
                );

            }


        } catch (error) {

            console.error(
                "Health check failed:",
                error
            );


            setOffline(
                apiStatus,
                apiDot,
                "Unavailable"
            );


            setOffline(
                modelStatus,
                modelDot,
                "Unavailable"
            );

        }

    }


    /* =====================================================
       CHECK DATABASE
       ===================================================== */

    async function checkDatabase() {

        try {

            const response =
                await fetch(
                    "/api/history?limit=1",
                    {
                        method: "GET"
                    }
                );


            if (!response.ok) {
                throw new Error(
                    "Database request failed"
                );
            }


            setOnline(
                databaseStatus,
                databaseDot,
                "Connected"
            );


        } catch (error) {

            console.error(
                "Database check failed:",
                error
            );


            setOffline(
                databaseStatus,
                databaseDot,
                "Unavailable"
            );

        }

    }


    /* =====================================================
       RUN SYSTEM CHECKS
       ===================================================== */

    checkSystemHealth();
    checkDatabase();

});