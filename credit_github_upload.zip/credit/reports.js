document.addEventListener("DOMContentLoaded", function () {

    let transactions = [];


    // =====================================================
    // LOAD REPORT DATA
    // =====================================================

    async function loadReports() {

        try {

            const response =
                await fetch("/api/history?limit=500");

            const result =
                await response.json();


            if (!response.ok || !result.success) {

                throw new Error(
                    result.error ||
                    "Unable to load report data."
                );

            }


            transactions =
                result.data || [];


            await updateSummary();

            updateReportTable();

            updateReportAnalytics();

        }

        catch (error) {

            console.error(
                "Reports loading error:",
                error
            );

        }

    }


    // =====================================================
    // SUMMARY CARDS
    // =====================================================

    async function updateSummary() {

        try {

            const response =
                await fetch("/api/analytics");

            const data =
                await response.json();


            if (!response.ok || !data.success) {

                throw new Error(
                    data.error ||
                    "Unable to load analytics."
                );

            }


            const cards =
                document.querySelectorAll(
                    ".report-card"
                );


            if (cards.length < 4) {

                return;

            }


            const total =
                cards[0].querySelector("h2");

            const fraud =
                cards[1].querySelector("h2");

            const genuine =
                cards[2].querySelector("h2");

            const rate =
                cards[3].querySelector("h2");


            if (total) {

                total.textContent =
                    formatNumber(
                        data.total_predictions
                    );

            }


            if (fraud) {

                fraud.textContent =
                    formatNumber(
                        data.fraud_predictions
                    );

            }


            if (genuine) {

                genuine.textContent =
                    formatNumber(
                        data.genuine_predictions
                    );

            }


            if (rate) {

                rate.textContent =
                    `${data.fraud_rate || 0}%`;

            }

        }

        catch (error) {

            console.error(
                "Summary error:",
                error
            );

        }

    }


    // =====================================================
    // REPORT TABLE
    // =====================================================

    function updateReportTable() {

        const tbody =
            document.querySelector(
                ".report-table-section tbody"
            );


        if (!tbody) {

            return;

        }


        tbody.innerHTML = "";


        if (transactions.length === 0) {

            tbody.innerHTML = `

                <tr>

                    <td colspan="7">
                        No transactions available.
                    </td>

                </tr>

            `;

            return;

        }


        transactions
            .slice(0, 20)
            .forEach(transaction => {

                const row =
                    document.createElement("tr");


                const status =
                    String(
                        transaction.status || ""
                    ).toUpperCase();


                const statusClass =
                    status === "FRAUD"
                        ? "fraud"
                        : "genuine";


                row.innerHTML = `

                    <td>
                        TXN${String(
                            transaction.id
                        ).padStart(6, "0")}
                    </td>

                    <td>
                        ${formatDate(
                            transaction.transaction_date
                        )}
                    </td>

                    <td>
                        ₹${Number(
                            transaction.amount || 0
                        ).toLocaleString("en-IN")}
                    </td>

                    <td>
                        ${escapeHTML(
                            transaction.merchant || "-"
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            transaction.location || "-"
                        )}
                    </td>

                    <td>
                        ${Number(
                            transaction.risk_score || 0
                        ).toFixed(2)}%
                    </td>

                    <td>
                        <span class="status ${statusClass}">
                            ${escapeHTML(status || "-")}
                        </span>
                    </td>

                `;


                tbody.appendChild(row);

            });

    }


    // =====================================================
    // REPORT ANALYTICS
    // =====================================================

    function updateReportAnalytics() {

        const fraudTransactions =
            transactions.filter(
                transaction =>
                    String(
                        transaction.status || ""
                    ).toUpperCase() === "FRAUD"
            );


        const analyticsCards =
            document.querySelectorAll(
                ".analytics-card"
            );


        // -------------------------------------------------
        // Monthly Fraud Trend
        // -------------------------------------------------

        if (analyticsCards[0]) {

            const paragraph =
                analyticsCards[0]
                    .querySelector("p");


            if (paragraph) {

                paragraph.innerHTML =
                    `The report contains <strong>${
                        fraudTransactions.length
                    }</strong> fraud transaction(s).`;

            }

        }


        // -------------------------------------------------
        // Highest Risk Location
        // -------------------------------------------------

        const locationCounts = {};


        fraudTransactions.forEach(
            transaction => {

                const location =
                    transaction.location ||
                    "Unknown";


                locationCounts[location] =
                    (locationCounts[location] || 0)
                    + 1;

            }
        );


        const topLocation =
            Object.entries(
                locationCounts
            )
            .sort(
                (a, b) =>
                    b[1] - a[1]
            )[0];


        if (analyticsCards[1]) {

            const paragraph =
                analyticsCards[1]
                    .querySelector("p");


            if (paragraph) {

                paragraph.textContent =
                    topLocation
                        ? `${topLocation[0]} recorded ${topLocation[1]} fraud transaction(s).`
                        : "No fraud transactions recorded yet.";

            }

        }


        // -------------------------------------------------
        // Top Fraud Merchant
        // -------------------------------------------------

        const merchantCounts = {};


        fraudTransactions.forEach(
            transaction => {

                const merchant =
                    transaction.merchant ||
                    "Unknown";


                merchantCounts[merchant] =
                    (merchantCounts[merchant] || 0)
                    + 1;

            }
        );


        const topMerchant =
            Object.entries(
                merchantCounts
            )
            .sort(
                (a, b) =>
                    b[1] - a[1]
            )[0];


        if (analyticsCards[2]) {

            const paragraph =
                analyticsCards[2]
                    .querySelector("p");


            if (paragraph) {

                paragraph.textContent =
                    topMerchant
                        ? `${topMerchant[0]} recorded ${topMerchant[1]} fraud transaction(s).`
                        : "No fraud transactions recorded yet.";

            }

        }


        // -------------------------------------------------
        // Monthly Report Summary
        // -------------------------------------------------

        const summary =
            document.querySelector(
                ".report-summary p"
            );


        if (summary) {

            const total =
                transactions.length;


            const fraud =
                fraudTransactions.length;


            const genuine =
                total - fraud;


            const fraudRate =
                total > 0
                    ? (
                        fraud /
                        total *
                        100
                    ).toFixed(2)
                    : "0.00";


            summary.innerHTML = `

                The Fraud Detection System analyzed

                <strong>
                    ${formatNumber(total)}
                </strong>

                transactions.

                Out of them,

                <strong>
                    ${formatNumber(fraud)}
                </strong>

                were classified as fraudulent,

                <strong>
                    ${formatNumber(genuine)}
                </strong>

                were genuine.

                The overall fraud rate is

                <strong>
                    ${fraudRate}%
                </strong>.

            `;

        }

    }


    // =====================================================
    // SEARCH
    // =====================================================

    const searchInput =
        document.querySelector(
            ".filter-group.search input"
        );


    if (searchInput) {

        searchInput.addEventListener(
            "input",
            applySearch
        );

    }


    function applySearch() {

        const value =
            searchInput.value
                .toLowerCase()
                .trim();


        const filtered =
            transactions.filter(
                transaction => {

                    const id =
                        `txn${String(
                            transaction.id
                        ).padStart(6, "0")}`;


                    const merchant =
                        String(
                            transaction.merchant || ""
                        );


                    return (

                        id.includes(value)

                        ||

                        merchant
                            .toLowerCase()
                            .includes(value)

                    );

                }
            );


        renderFilteredTable(
            filtered
        );

    }


    // =====================================================
    // FILTER BY STATUS
    // =====================================================

    const filterSelects =
        document.querySelectorAll(
            ".filter-group select"
        );


    if (filterSelects.length > 0) {

        filterSelects[0]
            .addEventListener(
                "change",
                applyStatusFilter
            );

    }


    function applyStatusFilter() {

        const selected =
            filterSelects[0].value
                .toUpperCase();


        if (
            selected === "ALL" ||
            selected === ""
        ) {

            updateReportTable();

            return;

        }


        const filtered =
            transactions.filter(
                transaction =>
                    String(
                        transaction.status || ""
                    ).toUpperCase() ===
                    selected
            );


        renderFilteredTable(
            filtered
        );

    }


    // =====================================================
    // FILTERED TABLE
    // =====================================================

    function renderFilteredTable(
        data
    ) {

        const tbody =
            document.querySelector(
                ".report-table-section tbody"
            );


        if (!tbody) {

            return;

        }


        tbody.innerHTML = "";


        if (data.length === 0) {

            tbody.innerHTML = `

                <tr>

                    <td colspan="7">
                        No matching transactions.
                    </td>

                </tr>

            `;

            return;

        }


        data
            .slice(0, 20)
            .forEach(transaction => {

                const row =
                    document.createElement("tr");


                const status =
                    String(
                        transaction.status || ""
                    ).toUpperCase();


                row.innerHTML = `

                    <td>
                        TXN${String(
                            transaction.id
                        ).padStart(6, "0")}
                    </td>

                    <td>
                        ${formatDate(
                            transaction.transaction_date
                        )}
                    </td>

                    <td>
                        ₹${Number(
                            transaction.amount || 0
                        ).toLocaleString("en-IN")}
                    </td>

                    <td>
                        ${escapeHTML(
                            transaction.merchant || "-"
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            transaction.location || "-"
                        )}
                    </td>

                    <td>
                        ${Number(
                            transaction.risk_score || 0
                        ).toFixed(2)}%
                    </td>

                    <td>
                        ${escapeHTML(status || "-")}
                    </td>

                `;


                tbody.appendChild(row);

            });

    }


    // =====================================================
    // REFRESH
    // =====================================================

    const refreshButton =
        document.querySelector(
            ".btn.refresh"
        );


    if (refreshButton) {

        refreshButton.addEventListener(
            "click",
            function () {

                loadReports();

            }
        );

    }


    // =====================================================
    // PRINT
    // =====================================================

    const printButton =
        document.querySelector(
            ".btn.print"
        );


    if (printButton) {

        printButton.addEventListener(
            "click",
            function () {

                window.print();

            }
        );

    }


    // =====================================================
    // CSV
    // =====================================================

    const csvButton =
        document.querySelector(
            ".btn.csv"
        );


    if (csvButton) {

        csvButton.addEventListener(
            "click",
            exportCSV
        );

    }


    function exportCSV() {

        if (transactions.length === 0) {

            alert(
                "No transaction data available."
            );

            return;

        }


        const headers = [

            "Transaction ID",
            "Date",
            "Amount",
            "Merchant",
            "Location",
            "Risk Score",
            "Status"

        ];


        const rows =
            transactions.map(
                transaction => [

                    `TXN${String(
                        transaction.id
                    ).padStart(6, "0")}`,

                    transaction.transaction_date || "",

                    transaction.amount || 0,

                    transaction.merchant || "",

                    transaction.location || "",

                    transaction.risk_score || 0,

                    transaction.status || ""

                ]
            );


        const csvContent = [

            headers,

            ...rows

        ]
        .map(
            row =>
                row
                    .map(
                        value =>
                            `"${String(
                                value
                            ).replace(
                                /"/g,
                                '""'
                            )}"`
                    )
                    .join(",")
        )
        .join("\n");


        const blob =
            new Blob(
                [csvContent],
                {
                    type:
                        "text/csv;charset=utf-8;"
                }
            );


        const url =
            URL.createObjectURL(blob);


        const link =
            document.createElement("a");


        link.href = url;

        link.download =
            "fraud_transaction_report.csv";


        document.body.appendChild(link);

        link.click();

        link.remove();


        URL.revokeObjectURL(url);

    }


    // =====================================================
    // PDF
    // =====================================================

    const pdfButton =
        document.querySelector(
            ".btn.download"
        );


    if (pdfButton) {

        pdfButton.addEventListener(
            "click",
            downloadPDF
        );

    }


    async function downloadPDF() {

        try {

            pdfButton.disabled = true;


            pdfButton.innerHTML =
                '<i class="fa-solid fa-spinner fa-spin"></i> Generating PDF...';


            const response =
                await fetch(
                    "/api/report/pdf"
                );


            if (!response.ok) {

                let errorMessage =
                    "Unable to generate PDF report.";


                try {

                    const errorData =
                        await response.json();


                    if (errorData.error) {

                        errorMessage =
                            errorData.error;

                    }

                }

                catch (_) {

                    // Keep default error message.

                }


                throw new Error(
                    errorMessage
                );

            }


            const blob =
                await response.blob();


            const url =
                window.URL.createObjectURL(
                    blob
                );


            const link =
                document.createElement("a");


            link.href = url;

            link.download =
                "fraud_transaction_report.pdf";


            document.body.appendChild(link);

            link.click();

            link.remove();


            window.URL.revokeObjectURL(
                url
            );

        }

        catch (error) {

            console.error(
                "PDF download error:",
                error
            );


            alert(
                "PDF download failed.\n\n" +
                error.message
            );

        }

        finally {

            pdfButton.disabled = false;

            pdfButton.innerHTML =
                '<i class="fa-solid fa-file-pdf"></i> Download PDF';

        }

    }


    // =====================================================
    // HELPERS
    // =====================================================

    function formatNumber(value) {

        return Number(
            value || 0
        ).toLocaleString(
            "en-IN"
        );

    }


    function formatDate(value) {

        if (!value) {

            return "-";

        }


        const date =
            new Date(value);


        if (isNaN(date.getTime())) {

            return value;

        }


        return date.toLocaleDateString(
            "en-IN"
        );

    }


    function escapeHTML(value) {

        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");

    }


    // =====================================================
    // START
    // =====================================================

    loadReports();

});