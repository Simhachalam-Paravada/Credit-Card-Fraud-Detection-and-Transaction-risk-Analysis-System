document.addEventListener("DOMContentLoaded", () => {

    // =========================================================
    // FORM ELEMENTS
    // =========================================================

    const form =
        document.getElementById("predictionForm") ||
        document.querySelector("form");

    const predictButton =
        document.getElementById("predictButton");

    const buttonText =
        document.getElementById("buttonText");

    const buttonLoader =
        document.getElementById("buttonLoader");


    // =========================================================
    // INPUT FIELDS
    // =========================================================

    const amount =
        document.getElementById("amount");

    const merchant =
        document.getElementById("merchant");

    const date =
        document.getElementById("date");

    const time =
        document.getElementById("time");

    const location =
        document.getElementById("location");

    const distance =
        document.getElementById("distance");

    const age =
        document.getElementById("age");

    const gender =
        document.getElementById("gender");

    const occupation =
        document.getElementById("occupation");

    const income =
        document.getElementById("income");

    const cardType =
        document.getElementById("card_type");

    const deviceType =
        document.getElementById("device_type");


    // =========================================================
    // RESULT ELEMENTS
    // =========================================================

    const resultCard =
        document.getElementById("resultCard");

    const status =
        document.getElementById("status");

    const probability =
        document.getElementById("probability");

    const riskLevel =
        document.getElementById("riskLevel");

    const flag =
        document.getElementById("flag");


    // =========================================================
    // PREVENT ACCIDENTAL MOUSE-WHEEL CHANGES
    // =========================================================
    // Normal mouse wheel scrolling will NOT change
    // number input values.
    //
    // Hold SHIFT + mouse wheel if you intentionally
    // want to change a number field using the wheel.
    // =========================================================

    document.querySelectorAll('input[type="number"]').forEach((input) => {

        input.addEventListener(
            "wheel",
            (event) => {

                if (!event.shiftKey) {
                    event.preventDefault();
                }

            },
            {
                passive: false
            }
        );

    });


    // =========================================================
    // RESULT CLASS CLEANUP
    // =========================================================

    function clearResultClasses() {

        if (status) {

            status.classList.remove(
                "result-fraud",
                "result-genuine",
                "fraud",
                "genuine"
            );
        }


        if (riskLevel) {

            riskLevel.classList.remove(
                "risk-high",
                "risk-medium",
                "risk-low",
                "high",
                "medium",
                "low"
            );
        }


        if (flag) {

            flag.classList.remove(
                "flag-danger",
                "flag-warning",
                "flag-normal",
                "danger",
                "warning",
                "normal"
            );
        }
    }


    // =========================================================
    // SHOW RESULT
    // =========================================================

    function showResult(data) {

        if (!resultCard) {
            return;
        }


        clearResultClasses();


        // -----------------------------------------------------
        // TRANSACTION STATUS
        // -----------------------------------------------------

        if (status) {

            status.textContent =
                data.prediction || "--";


            const prediction =
                String(
                    data.prediction || ""
                ).toUpperCase();


            if (prediction === "FRAUD") {

                status.classList.add(
                    "result-fraud"
                );

            } else {

                status.classList.add(
                    "result-genuine"
                );
            }
        }


        // -----------------------------------------------------
        // FRAUD PROBABILITY
        // -----------------------------------------------------

        if (probability) {

            const fraudProbability =
                Number(
                    data.fraud_probability
                );


            probability.textContent =
                Number.isFinite(fraudProbability)
                    ? `${fraudProbability.toFixed(2)}%`
                    : "--";
        }


        // -----------------------------------------------------
        // RISK LEVEL
        // -----------------------------------------------------

        if (riskLevel) {

            riskLevel.textContent =
                data.risk_level || "--";


            const level =
                String(
                    data.risk_level || ""
                ).toUpperCase();


            if (level === "HIGH") {

                riskLevel.classList.add(
                    "risk-high"
                );

            } else if (level === "MEDIUM") {

                riskLevel.classList.add(
                    "risk-medium"
                );

            } else {

                riskLevel.classList.add(
                    "risk-low"
                );
            }
        }


        // -----------------------------------------------------
        // SUSPICIOUS TRANSACTION
        // -----------------------------------------------------

        if (flag) {

            flag.textContent =
                data.suspicious_flag || "--";


            const suspicious =
                String(
                    data.suspicious_flag || ""
                ).toUpperCase();


            if (
                suspicious === "SUSPICIOUS"
            ) {

                flag.classList.add(
                    "flag-danger"
                );

            } else if (
                suspicious === "REVIEW"
            ) {

                flag.classList.add(
                    "flag-warning"
                );

            } else {

                flag.classList.add(
                    "flag-normal"
                );
            }
        }


        // -----------------------------------------------------
        // SHOW RESULT CARD
        // -----------------------------------------------------

        resultCard.classList.remove(
            "show"
        );


        setTimeout(() => {

            resultCard.classList.add(
                "show"
            );


            resultCard.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

        }, 100);
    }


    // =========================================================
    // BUTTON LOADING STATE
    // =========================================================

    function setLoading(isLoading) {

        if (!predictButton) {
            return;
        }


        predictButton.disabled =
            isLoading;


        if (isLoading) {

            if (buttonText) {

                buttonText.textContent =
                    "Analyzing...";
            }


            if (buttonLoader) {

                buttonLoader.style.display =
                    "inline-block";
            }

        } else {

            if (buttonText) {

                buttonText.textContent =
                    "Analyze Transaction";
            }


            if (buttonLoader) {

                buttonLoader.style.display =
                    "none";
            }
        }
    }


    // =========================================================
    // RESET RESULT
    // =========================================================

    function resetResult() {

        if (status) {
            status.textContent = "--";
        }


        if (probability) {
            probability.textContent = "--";
        }


        if (riskLevel) {
            riskLevel.textContent = "--";
        }


        if (flag) {
            flag.textContent = "--";
        }


        clearResultClasses();
    }


    // =========================================================
    // CHECK FORM
    // =========================================================

    if (!form) {

        console.error(
            "Prediction form not found."
        );

        return;
    }


    // =========================================================
    // FORM SUBMIT
    // =========================================================

    form.addEventListener(
        "submit",
        async (event) => {

            event.preventDefault();


            resetResult();


            // =================================================
            // GET NUMERIC VALUES
            // =================================================

            const amountValue =
                Number(
                    amount?.value
                );

            const ageValue =
                Number(
                    age?.value
                );

            const incomeValue =
                Number(
                    income?.value
                );

            const distanceValue =
                Number(
                    distance?.value
                );


            // =================================================
            // REQUIRED FIELD VALIDATION
            // =================================================

            if (
                !amount?.value ||
                !merchant?.value ||
                !date?.value ||
                !time?.value ||
                !location?.value ||
                !age?.value ||
                !gender?.value ||
                !occupation?.value ||
                !income?.value ||
                !cardType?.value ||
                !deviceType?.value ||
                !distance?.value
            ) {

                alert(
                    "Please fill in all transaction details before analyzing."
                );

                return;
            }


            // =================================================
            // AMOUNT VALIDATION
            // =================================================

            if (
                !Number.isFinite(
                    amountValue
                ) ||
                amountValue <= 0
            ) {

                alert(
                    "Transaction Amount must be greater than 0."
                );

                amount?.focus();

                return;
            }


            // =================================================
            // AGE VALIDATION
            // =================================================

            if (
                !Number.isInteger(
                    ageValue
                ) ||
                ageValue < 1 ||
                ageValue > 120
            ) {

                alert(
                    "Please enter a valid age between 1 and 120."
                );

                age?.focus();

                return;
            }


            // =================================================
            // INCOME VALIDATION
            // =================================================

            if (
                !Number.isFinite(
                    incomeValue
                ) ||
                incomeValue <= 0
            ) {

                alert(
                    "Customer Income must be greater than 0."
                );

                income?.focus();

                return;
            }


            // =================================================
            // DISTANCE VALIDATION
            // =================================================

            if (
                !Number.isFinite(
                    distanceValue
                ) ||
                distanceValue < 0
            ) {

                alert(
                    "Transaction Distance cannot be negative."
                );

                distance?.focus();

                return;
            }


            // =================================================
            // BUILD REQUEST DATA
            // =================================================

            const requestData = {

                amount:
                    amountValue,

                merchant:
                    merchant.value.trim(),

                date:
                    date.value,

                time:
                    time.value,

                location:
                    location.value.trim(),

                age:
                    ageValue,

                gender:
                    gender.value,

                occupation:
                    occupation.value,

                income:
                    incomeValue,

                card_type:
                    cardType.value,

                device_type:
                    deviceType.value,

                distance:
                    distanceValue
            };


            console.log(
                "Sending transaction data:",
                requestData
            );


            // =================================================
            // CALL FLASK BACKEND
            // =================================================

            try {

                setLoading(true);


                const response =
                    await fetch(
                        "/api/predict",
                        {
                            method:
                                "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body:
                                JSON.stringify(
                                    requestData
                                )
                        }
                    );


                // =================================================
                // READ RESPONSE
                // =================================================

                const data =
                    await response.json();


                console.log(
                    "Prediction response:",
                    data
                );


                // =================================================
                // BACKEND ERROR
                // =================================================

                if (
                    !response.ok ||
                    !data.success
                ) {

                    throw new Error(
                        data.error ||
                        "Prediction failed."
                    );
                }


                // =================================================
                // DISPLAY RESULT
                // =================================================

                showResult(
                    data
                );


            } catch (error) {

                console.error(
                    "Prediction error:",
                    error
                );


                alert(
                    `Unable to analyze transaction.\n\n${error.message}`
                );


            } finally {

                setLoading(false);
            }

        }
    );

});
